/*****************************************************************************************
 * Copyright: (c) 2000-2002 Infomosaic Corporation.
 * All rights reserved.
 * It is violation of international law to use this code without proper written authorization
 * and license agreement from Infomosaic Corporation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL INFOMOSAIC CORPORATION  OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * Author: 
 * Date:   
 * Change history:
 *
 * Date		|	Modified By		|	Brief description of the modification
 *
 *
 *****************************************************************************************
 */
// Signature.h : Declaration of the CSignature

#ifndef __SIGNATURE_H_
#define __SIGNATURE_H_

#include "resource.h"       // main symbols
#include <objsafe.h>
#include <vector>
#include <docobj.h>			// IOleCommandTarget interface declaration
#include <ocidl.h>			// IObjectWithSite interface declaration
#include <shobjidl.h>		// IShellBrowser interface declaration


#if __cplusplus
extern "C" {
#endif

#include <securexml/ax.h>
#include <securexml/errors.h>
#include <securexml/cr.h>


#if __cplusplus
}
#endif


#include "License.h"
#include "config.h"

#include "showselectcert.h"
#include "CAMClient.h"
#include "CertVerify.h"

#import "..\lib\NetscapeCert.dll"
using namespace NetscapeCert;

using namespace Gdiplus;

#define NOT_INITIALIZED		-1
#define USE_PFX_CERT		-2
#define USE_BASE64_CERT		-3
#define ACTIVE_CERT_INFO	-3

#define WITH_COMMENTS		1
#define WITHOUT_COMMENTS	0

#define MAX_PROP_COUNT		32
#define SIGN_ALLOWED		0x01
#define VERIFY_ALLOWED		0x02
#define ENCRYPT_ALLOWED		0x04
#define DECRYPT_ALLOWED		0x08
#define SECURESIGN_ALLOWED	0x10
#define SECURESIGN_PROF_ALLOWED	0x20
#define SECURESIGN_ENTR_ALLOWED	0x40
#define SECURESIGN_SERVER_ALLOWED 0x80

#define MAX_TS_PROP_ATTR	1024

#define GUNZIP_BLOCK_SIZE	16*1024
#define CERT_SERIAL_PLAIN_HEX	1

#define NO_PHYSICAL_SIG			0
#define FILE_PHYSICAL_SIG		1
#define CAPTURE_PHYSICAL_SIG	2

// Various possible physical signature image sources
#define IMAGE_FROM_FILE		"Stored Disk Image"
#define IMAGE_FROM_MOUSE	"Live Mouse Signature Image"
#define IMAGE_FROM_TABLET	"Live Signature Pad Image"

// Various element Id prefixes
#define SIG_IMAGE_OBJECT_ID_PREFIX	"SignatureImage_"
#define WINDOW_IMAGE_OBJECT_ID_PREFIX	"WindowImage_"

//Various File Names
#define SECUREXML_CONFIG_FILENAME	"SecureXML.config"
#define SECUREXML_LICENSE_FILENAME	"SecureXMLLicense.xml"

//Netscape Certificate Store support
#define NETSCAPESTORE		"Netscape"

/* defines for various supported time formats */

#define TIME_RFC			0
#define TIME_VB_NOW			1
#define TIME_JS_UTC			2

/* defines for Email Server Type*/
#define EMAIL_SRVR_SMTP			1
#define EMAIL_SRVR_EXCH			2
#define DEFAULT_CONN_STR		L"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Program Files\\Infomosaic\\SecureXML\\SecureXML.mdb"
/*
 * This protocol is widely used by small computers running MS-DOS and similar operating systems. 
 * The server listens on port 13, and responds to requests in either tcp/ip or udp/ip formats. The 
 * standard does not specify an exact format for the Daytime Protocol, but requires that the time 
 * is sent using standard ASCII characters. NIST chose a time code format similar to the one used 
 * by its dial-up Automated Computer Time Service (ACTS), as shown below:
 *
 * JJJJJ YR-MO-DA HH:MM:SS TT L H msADV UTC(NIST) OTM
 * 
 * where:
 * JJJJJ is the Modified Julian Date (MJD). The MJD is the last five digits of the Julian Date, 
 * which is simply a count of the number of days since January 1, 4713 B.C. To get the Julian Date, 
 * add 2.4 million to the MJD.
 * 
 * YR-MO-DA is the date. It shows the last two digits of the year, the month, and the current day of month.
 * 
 * HH:MM:SS is the time in hours, minutes, and seconds. The time is always sent as Coordinated Universal Time (UTC). 
 * An offset needs to be applied to UTC to obtain local time. For example, Mountain Time in the U. S. is 7 hours 
 * behind UTC during Standard Time, and 6 hours behind UTC during Daylight Saving Time.
 * 
 * TT is a two digit code (00 to 99) that indicates whether the United States is on Standard Time (ST) or 
 * Daylight Saving Time (DST). It also indicates when ST or DST is approaching. This code is set to 00 when 
 * ST is in effect, or to 50 when DST is in effect. During the month in which the time change actually occurs, 
 * this number will decrement every day until the change occurs. For example, during the month of October, 
 * the U.S. changes from DST to ST. On October 1, the number will change from 50 to the actual number of days 
 * until the time change. It will decrement by 1 every day until the change occurs at 2 a.m. local time when 
 * the value is 1. Likewise, the spring change is at 2 a.m. local time when the value reaches 51.
 * 
 * L is a one-digit code that indicates whether a leap second will be added or subtracted at midnight on the 
 * last day of the current month. If the code is 0, no leap second will occur this month. If the code is 1, 
 * a positive leap second will be added at the end of the month. This means that the last minute of the month 
 * will contain 61 seconds instead of 60. If the code is 2, a second will be deleted on the last day of the 
 * month. Leap seconds occur at a rate of about one per year. They are used to correct for irregularity in 
 * the earth's rotation. The correction is made just before midnight UTC (not local time).
 * 
 * H is a health digit that indicates the health of the server. If H=0, the server is healthly. If H=1, then 
 * the server is operating properly but its time may be in error by up to 5 seconds. This state should change 
 * to fully healthy within 10 minutes. If H=2, then the server is operating properly but its time is known 
 * to be wrong by more than 5 seconds. If H=4, then a hardware or software failure has occurred and the 
 * amount of the time error is unknown.
 *
 * msADV displays the number of milliseconds that NIST advances the time code to partially compensate for 
 * network delays. The advance is currently set to 50.0 milliseconds.
 *
 * The label UTC(NIST) is contained in every time code. It indicates that you are receiving Coordinated 
 * Universal Time (UTC) from the National Institute of Standards and Technology (NIST).
 *
 * OTM (on-time marker) is an asterisk (*). The time values sent by the time code refer to the arrival time 
 * of the OTM. In other words, if the time code says it is 12:45:45, this means it is 12:45:45 when the OTM arrives.
 *
 * Example:
 *
 * 52478 02-07-23 22:37:41 50 0 0 558.1 UTC(NIST) 
*/


struct BufferLinkedList
{
	unsigned char *bufferPtr;
	unsigned long bufferSize;
	struct BufferLinkedList *next;
};


/////////////////////////////////////////////////////////////////////////////
// CSignature

class ATL_NO_VTABLE CSignature : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSignature, &CLSID_Signature>,
	public IDispatchImpl<ISignature, &IID_ISignature, &LIBID_XMLSIGNLib>,
	public IOleCommandTarget,
	public IObjectWithSite

{
public:
	CSignature();
	~CSignature();

// See UpdateRegistry static function below
// DECLARE_REGISTRY_RESOURCEID(IDR_SIGNATURE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSignature)
	COM_INTERFACE_ENTRY(ISignature)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IOleCommandTarget)
	COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()

// ISignature
public:
	STDMETHOD(put_CertificateTrustExplicit)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_CertificatePolicyExplicit)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_CertificatePolicyExplicit)(/*[in]*/ BOOL newVal);
	STDMETHOD(put_DoDCompliance)(/*[in]*/ BOOL newVal);
	STDMETHOD(put_CertificatePathLengthChecking)(/*[in]*/ BOOL newVal);
	STDMETHOD(put_CertificateChainValidation)(/*[in]*/ BOOL newVal);
	STDMETHOD(put_CertificatePolicyChecking)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_UserConstrainedPolicy)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(get_AuthorityConstrainedPolicy)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(put_CertificatePolicy)(/*[in]*/ VARIANT newVal);
	STDMETHOD(VerifyActiveCertificate)(BOOL *result);
	STDMETHOD(put_CRLLocation)(/*[in]*/ VARIANT newVal);
	STDMETHOD(put_ConfigFileName)(/*[in]*/ BSTR newVal);
	BSTR * GetBstrArrayFromVariant(VARIANT fileList, UINT *itemCount);
	STDMETHOD(SignFiles)(/*[in]*/ VARIANT fileList, /*[in]*/ BSTR outFileName, /*[out, retval]*/ BSTR *outFilePath);
	STDMETHOD(CoSignFile)(/*[in]*/ BSTR inputSignedXMLFile, /*[in]*/ BSTR outFileName, /*[out, retval]*/ BSTR *outFilePath);
	STDMETHOD(put_OverwriteFile)(/*[in]*/ BOOL newVal);
	STDMETHOD(CoSignXMLStr)(/*[in]*/ BSTR signedDataXMLStr, /*[out, retval]*/ BSTR *coSignedXMLStr);
	STDMETHOD(put_ExcludeSignerCertificate)(/*[in]*/ BOOL newVal);
	STDMETHOD(SignDataStr)(/*[in]*/ BSTR dataStrPtr, /*[out, retval]*/ BSTR *signedXMLStr);
	STDMETHOD(CaptureLiveSignature)(/*[out, retval]*/ BSTR *signatureFilePath);
	STDMETHOD(put_DetailedVerificationFlag)(/*[in]*/ BOOL newVal);
	STDMETHOD(ChangeOrAddProperty)(BSTR propertyName, BSTR propertyValue);
	STDMETHOD(get_HMACPassword)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_HMACPassword)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_UseHMAC)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_UseHMAC)(/*[in]*/ BOOL newVal);
	STDMETHOD(SignXMLXpathStr)(BSTR xmlStr, BSTR xpathExp, BSTR signatureId, BSTR *signedXMLStr);

	
	STDMETHOD(get_AddWindowImage)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_AddWindowImage)(/*[in]*/ BOOL newVal);
	void AddWindowImage(xmlNodePtr sigNode, xmlNodePtr signedInfoNode, char *charSigId);
	BOOL GetPhysicalSignatureFromMouse(char *filePathBuf, int bufSize, char *guidStr);
	BOOL GetPhysicalSignatureFromTablet(char *filePathBuf, int bufSize, char *guidStr);
	STDMETHOD(VerifyPFXCertCRL)(/*[in]*/ BSTR pfxFileName, /*[in]*/ BSTR pfxPassword, /*[in]*/ BSTR atTime, /*[in]*/ long timeFormat, /*[out, retval]*/ BOOL *pVal);
	STDMETHOD(VerifyX509CertCRL)(/*[in]*/ BSTR certData, /*[in]*/ BSTR atTime, /*[in]*/ long timeFormat, /*[out, retval]*/ BOOL *pVal);
	STDMETHOD(get_SigCertStatus)(/*[in]*/ long sigIndex, /*[in]*/ BSTR atTime, /*[in]*/ long timeFormat, /*[out, retval]*/ long *pVal);
	STDMETHOD(get_CrlChecking)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_CrlChecking)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_HostOsType)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_TimeStamping)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_TimeStamping)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_TimeStampURL)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_TimeStampURL)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_HostName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(PFXExportActiveCertificate)(/*[in]*/ BSTR password, /*[out, retval]*/ BSTR *pfxFilePath);
	STDMETHOD(SetActivePFXFileCert)(/*[in]*/ BSTR pfxFileName, /*[in]*/ BSTR pfxPassword, /*[out, retval]*/ BSTR *pfxX509Cert);
	STDMETHOD(VerifyXMLStr)(/*[in]*/ BSTR signedXML, /*[out, retval]*/ BOOL *sigStatus);
	STDMETHOD(SelectActiveCertificate)(/*[out, retval]*/ BSTR *certID);
	STDMETHOD(ViewAnyCertificate)(/*[in]*/ BSTR inputX509Data);

// IOleCommandTarget
	HRESULT STDMETHODCALLTYPE QueryStatus(const GUID *pguidCmdGroup, ULONG cCmds, OLECMD prgCmds[], OLECMDTEXT *pCmdText);
	HRESULT STDMETHODCALLTYPE Exec(const GUID *pguidCmdGroup, DWORD nCmdID, DWORD nCmdExecOpt, VARIANTARG *pvaIn, VARIANTARG *pvaOut );

// IObjectWithSite
	STDMETHODIMP SetSite(IUnknown* pUnkSite);
	STDMETHODIMP GetSite(REFIID riid, void **ppvSite);

	STDMETHOD(GetPropertyCount)(/*[in]*/ long sigIndex, /*[out, retval]*/ long *propCount);
	STDMETHOD(GetLicenseStatus)(/*[out, retval]*/ long *licStatus);
	STDMETHOD(GetVersion)(/*[out, retval]*/ BSTR *version);
	STDMETHOD(SignXMLEnveloped)(/*[in]*/ BSTR inputXML, /*[in]*/ BSTR sigId, /*[out, retval]*/ BSTR *signedXML);
	//CSignature(BSTR StoreName);
	STDMETHOD(GetStoreName)(/*[out, retval]*/ BSTR *storeName);
	STDMETHOD(SetStoreName)(/*[in]*/ BSTR storeName);
	STDMETHOD(GetSignedFileObject)(/*[in]*/ BSTR signedXML, /*[in]*/ BSTR saveDir, /*[out, retval]*/ BSTR *signedFilePath);
	STDMETHOD(SignFile)(/*[in]*/ BSTR inputFile, /*[in]*/ BSTR outputFile);
	STDMETHOD(GetSignedHTML)(/*[in]*/ BSTR signedHtmlXML, /*[out, retval]*/ BSTR *originalHTML);
	STDMETHOD(SetCSP)(/*[in]*/ BSTR CSPName);
	STDMETHOD(SecureXMLVerify)(/*[in]*/ BSTR signedXML, /*[out, retval]*/ BSTR *verificationResponse);
	STDMETHOD(SignHTML)(/*[in]*/ IDispatch *document, /*[out, retval]*/ BSTR *signedHTML);
	STDMETHOD(SaveXMLStr)(/*[in]*/ BSTR inputXMLStr, /*[in]*/ BSTR fileName, /*[out, retval]*/ BSTR *path);
	STDMETHOD(ReadAll)(/*[in]*/ BSTR fileName, /*[out, retval]*/ BSTR *fileDataStr);
	STDMETHOD(SignXMLStr)(/*[in]*/ BSTR xmlStr, /*[in]*/ BSTR signatureId, /*[out, retval]*/ BSTR *signedXMLStr);
	STDMETHOD(get_SignatureCount)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_FailedUri)(long index, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_FailedUriFullPath)(long index, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_FailedUriFullPath)(long index, /*[in]*/ BSTR newVal);
	STDMETHOD(get_TotalUriCount)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_FailedUriCount)(/*[out, retval]*/ long *pVal);
	STDMETHOD(FileExists)(/*[in]*/ BSTR fileName, /*[out, retval]*/ BOOL *fileStatus);
	STDMETHOD(get_CertSerialNumber)(/*[in]*/ BSTR sigId, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_CertExpiry)(/*[in]*/ BSTR sigId, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_CertIssuer)(/*[in]*/ BSTR sigId, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SignerSubject)(/*[in]*/ BSTR sigId, /*[out, retval]*/ BSTR *pVal);
	HRESULT SetSignatureValues(int signatureType);
	STDMETHOD(get_SignedDocumentPath)(/*[in]*/long sigIndex, /*[in]*/ long uriIndex, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(SetActiveCertificate)(/*[in]*/ BSTR certID, /*[out, retval]*/ BOOL *status);
	STDMETHOD(GetCertificateInfo)(/*[in]*/ long index, /*[in]*/ long valIndex, /*[out, retval]*/ BSTR *value);
	STDMETHOD(get_CertificateCount)(/*[out, retval]*/ long *pVal);
	STDMETHOD(ViewCertificate)(/*[in]*/ BSTR certID);
	STDMETHOD(GetX509Certificate)(/*[in]*/ BSTR certID, /*[out, retval]*/ BSTR *certData);
	STDMETHOD(GetLastError)(/*[out, retval]*/ long *errorNum);
	STDMETHOD(VerifyDetached)(/*[in]*/ BSTR signatureFileName, /*[out, retval]*/ BOOL *sigStatus);
	STDMETHOD(PFXExportCertificate)(/*[in]*/ BSTR certID, /*[in]*/ BSTR password, /*[out, retval]*/ BSTR *pfxFilePath);
	void Empty();
	void FreeUriArr();
	void FetchSignatureStatus(BOOL verifyResult);
	BOOL ReadAllBin(unsigned char *fileName, unsigned char **binData, DWORD *dwFileSize);
//	static unsigned char * HeapW2A(BSTR bstrStr);
	BOOL CreateSigFromTmplBlob(xmlDocPtr doc, char *sigId, unsigned char **signedXML, int *signedXMLSize);
	void AddPhysicalSignature(xmlNodePtr sigNode, xmlNodePtr signedInfoNode, char *charSigId);
	static _ATL_REGMAP_ENTRY RegEntries[];
	// Default implementation does not pass _ATL_REGMAP_ENTRY array
	// DECLARE_REGISTRY_RESOURCEID(IDR_SIGNATURE)
	static HRESULT WINAPI UpdateRegistry(BOOL bRegister)
	{
		return _Module.UpdateRegistryFromResource(IDR_SIGNATURE, bRegister, RegEntries);
	}


BEGIN_CATEGORY_MAP(CSignature)
	IMPLEMENTED_CATEGORY(CATID_SafeForScripting)
	IMPLEMENTED_CATEGORY(CATID_SafeForInitializing)
END_CATEGORY_MAP()

	PSIG_STATUS *sgArr;
	int err, signum;
	PURI_PATH *uriArr, *failedUriArr;
	int failedUriCount, totalUriCount;

	IShellBrowser *pSite;
	
	UINT RecipientCertificateCount;
	LPSTR *RecipientCertificateList;

	CComBSTR DecrytionPfxCertFile;
	BOOL DecryptUsingPfxFileCert;
	DS_DATA_BLOB DecrytionPfxPassword;

	UINT DetachedObjectCount;
	LPSTR *DetachedObjectList;
	UINT AttachedObjectCount;
	LPSTR *AttachedObjectList;

	UINT XpathNamespaceCount;
	LPSTR *XpathNamespaceList;

	int PropertyCount;
	PCERT_DESCR *cV;
	PCERT_DESCR *cVSigner;
	PCERT_DESCR *cVRecipient;
	int count;
	long CurrentCertificate;
	long CertificateCount;
	long RecipientCertCount;
	CComBSTR ErrorString;
	unsigned char *Properties[MAX_PROP_COUNT];
	CComBSTR SignatureID;
	CComBSTR SignerCertificate; 
	CComBSTR SignerSubject;		// Set after Verify
	CComBSTR CertIssuer;		// Set after Verify
	CComBSTR CertExpiry;		// Set after Verify
	CComBSTR CertSerialNumber;	// Set after Verify
	char szTempName[MAX_PATH]; 
	short DigestMethod;
	CComBSTR DocumentURI;
	CComBSTR RecipientCertificateStore;
	short EnvelopingFlag;
	PGLOBAL_SIG SigHandle;
	CComBSTR StoreName;
	CLicense LicObj;
	CConfig ConfObj;
	CComBSTR ReleaseVersion;
	DS_DATA_BLOB PfxPassword;
	DS_DATA_BLOB HMACPassword;
	unsigned char *PfxX509Cert;
	unsigned char  *B64PfxDataPtr;
	DS_DATA_BLOB PfxCertDataBlob;
	PCERT_DESCR  PfxCertInfo;
	CComBSTR	TimeStampURL;
	BOOL		TimeStampEnabled;
	BOOL		CrlCheckEnabled;
	long	PhysicalSigUsage;
	BOOL	CaptureSigOnce;
	BOOL	SignatureCaptured;
	char	PhysicalSignatureFileName[MAX_PATH+1];
	char	CapturedSignatureFileName[MAX_PATH+1];
	char	WindowImageFileName[MAX_PATH+1];
	RECT	SignatureCaptureWindowDim;
	string	SigImageGuid;
	BOOL	AddWindowImageFlag;
	GdiplusStartupInput gdiplusStartupInput;
	ULONG_PTR gdiplusToken;

	BOOL UseHMAC;
	CComBSTR HMACKey;
	CShowSelectCert *dlg;
	CShowSelectCert *dlgRecipient;
	BOOL DetailedVerificationReportFlag;
	BOOL ExcludeSignerCertificateFlag;
	BOOL OverwriteFileFlag;
	VERIFICATION_PARAMS CertVerifyParams;
	unsigned char *camServerHost;
	USHORT		  camServerPort;
	CCAMClient *pCamClient;
	BOOL	useCam;
	unsigned char agencyId[MAX_PATH];
	BOOL Base64EncodeXML;
	BOOL Base64DecodeXML;
	BOOL IncludeCamResponse;
	unsigned char *CamResponseAsciiCert;
	unsigned char *CamResponseCaSignedMsg;
	int CamResponseAsciiCertSize;
	int CamResponseCaSignedMsgSize;
	char pout[MAX_PATH * 2], pout2[MAX_PATH * 2];
	LONG CertSerialNumberFormat;

	LPSTR *allowedCertIssuerNames;
	UINT  allowedCertIssuerCount;

	CRLCache *pCrlCache;
	CComBSTR CRLCacheDbConnectionString;
	ULONG crlCacheTimeoutInMinutes;
	ULONG CanonicalizationMethod;

	ICertStore	*nsCertStoreObj;
	BSTR		nsStorePassword;
	BOOL		UsingNetscape;
	CComBSTR	SecureXMLPath;
	long		LogLevel;

	
	STDMETHOD(GetError)(/*[out, retval]*/ BSTR *errorString);
	STDMETHOD(Verify)(/*[in]*/ BSTR signatureFileName, /*[out, retval]*/ BOOL *sigStatus);
	STDMETHOD(SaveXMLSignature)(/*[in]*/ BSTR sigFileName);

	//STDMETHOD(GetXMLSignature)(/*[out, retval]*/ BSTR *xmlSignature);
	STDMETHOD(get_IncludeCamResponse)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_IncludeCamResponse)(/*[in]*/ BOOL newVal);

	STDMETHOD(Sign)(/*[in]*/ BSTR URI, /*[out, retval]*/ BSTR *tempFileName);
	STDMETHOD(get_PhysicalSignatureFile)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_PhysicalSignatureFile)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_CapturedSignatureFile)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_PhysicalSignatureUsage)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_PhysicalSignatureUsage)(/*[in]*/ long newVal);
	STDMETHOD(get_SignatureStatus)(/*[in]*/ long sigIndex, /*[out, retval]*/ BOOL *pVal);
	STDMETHOD(get_LogLevel)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_LogLevel)(/*[in]*/ long newVal);
	STDMETHOD(get_DigestObjectStatus)(/*[in]*/ long sigIndex, /*[in]*/ long uriIndex, /*[out, retval]*/ BOOL *pVal);
	STDMETHOD(get_DocumentURI)(/*[in]*/long sigIndex, /*[in]*/ long uriIndex, /*[out, retval]*/ BSTR *pVal);
//	STDMETHOD(get_DigestAlgorithm)(/*[in]*/long sigIndex, /*[in]*/ long uriIndex, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Base64DecodeXML)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_Base64DecodeXML)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_Base64EncodeXML)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_Base64EncodeXML)(/*[in]*/ BOOL newVal);
	//STDMETHOD(get_SignatureAlgorithm)(/*[in]*/ long index, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_Properties)(/*in*/ long sigIndex, /*in*/ long propIndex, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Properties)(/*in*/ long sigIndex, /*in*/ long propIndex, /*[in]*/ BSTR newVal);
	STDMETHOD(get_SignatureID)(/*[in]*/ long index, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_SignatureID)(/*[in]*/ long index,/*[in]*/ BSTR newVal);
	STDMETHOD(get_SignerCertificate)(/*in*/ long index, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_SignerCertificate)(/*in*/ long index, /*[in]*/ BSTR newVal);
	STDMETHOD(get_RecipientCertificateStore)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_RecipientCertificateStore)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_EnvelopingFlag)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_EnvelopingFlag)(/*[in]*/ short newVal);
protected:
public:
	STDMETHOD(put_XpathNamespace)(/*[in]*/ VARIANT newVal);
	STDMETHOD(put_RecipientCertificates)(VARIANT newVal);
	STDMETHOD(EncryptStr)(BSTR inputStr, BSTR* cipherStr);
	STDMETHOD(DecryptStr)(BSTR cipherText, BSTR* plainText);
	STDMETHOD(EncryptFile)(BSTR inputFile, BSTR outputFile, BSTR* encryptedFile);
	STDMETHOD(DecryptFile)(BSTR inputFile, BSTR outputFile, BSTR* decryptedFile);
	BYTE * EncryptBlob(DS_DATA_BLOB * blobPtr, unsigned long * encryptedSize);
	STDMETHOD(put_TrustedRoots)(VARIANT newVal);
	STDMETHOD(put_RecipientCertificateFiles)(VARIANT newVal);
	BOOL CheckCertificateValidity(BYTE * certData, LPSYSTEMTIME pSysTime, LPWSTR hKey, VERIFICATION_PARAMS * certVerParams, PGLOBAL_SIG pg_sig);
	BOOL crVerifyCertificateUsingCam(BYTE **certData, UINT certNum, LPSYSTEMTIME pSysTime, LPWSTR hKey, VERIFICATION_PARAMS *certVerParams, PGLOBAL_SIG pg_sig);
	STDMETHOD(put_DetachedObjects)(VARIANT newVal);
	STDMETHOD(put_AttachedObjects)(VARIANT newVal);
	STDMETHOD(ReadAllBase64)(BSTR uri, BSTR* base64EncodedData);
	STDMETHOD(put_DecryptionPFXCertFile)(BSTR newVal);
	STDMETHOD(put_DecryptUsingPFXFileCert)(BOOL newVal);
	STDMETHOD(put_DecryptionPFXPassword)(BSTR newVal);
	STDMETHOD(get_CamServerHost)(BSTR* pVal);
	STDMETHOD(put_CamServerHost)(BSTR newVal);
	STDMETHOD(get_CamServerPort)(USHORT* pVal);
	STDMETHOD(put_CamServerPort)(USHORT newVal);
	STDMETHOD(get_UseCam)(BOOL* pVal);
	STDMETHOD(put_UseCam)(BOOL newVal);
	STDMETHOD(get_AgencyId)(BSTR* pVal);
	STDMETHOD(put_AgencyId)(BSTR newVal);
	STDMETHOD(get_CamValidationResponse)(BSTR* pVal);
	STDMETHOD(GetSigPropValueByName)(LONG sigIndex, BSTR propName, BSTR* propValue);
	STDMETHOD(Base64DecodeBufferToFile)(BSTR encodedBuffer, BSTR outFilePath, BSTR* decodedFilePath);
	STDMETHOD(Base64DecodeFileToFile)(BSTR encodedFilePath, BSTR outFilePath, BSTR* decodedFilePath);
	STDMETHOD(GunZipFile)(BSTR gZippedFile, BSTR gUnZippedFile, BSTR* gUnZippedFilePath);
	void FreeBufferLinkedList(BufferLinkedList * listHeadPtr);
	STDMETHOD(get_CertSerialNumberFormat)(LONG *pVal);
	STDMETHOD(put_CertSerialNumberFormat)(LONG newVal);
	unsigned char *Base64BinToPlainHex(unsigned char *base64Bin);
	unsigned char *PlainHexToBase64Bin(unsigned char *plainHex);
	STDMETHOD(SecureXMLVerifyFileToBuffer)(BSTR signedXMLFile, BSTR* verificationResponse);
	STDMETHOD(SecureXMLVerifyFileToFile)(BSTR signedXMLFile, BSTR outFilePath, BSTR* verificationResponseFilePath);
	STDMETHOD(DeleteSignatureFromXMLStr)(BSTR signedXMLStr,  BSTR sigId, BSTR* newSigXMLStr);
	STDMETHOD(DeleteSignatureFromFile)(BSTR signedXMLFile, BSTR sigId, BSTR outFilePath, BSTR* newSigFilePath);
	STDMETHOD(put_AllowedCertIssuerNames)(VARIANT newVal);
	STDMETHOD(get_CRLCacheDbConnectionString)(BSTR* pVal);
	STDMETHOD(put_CRLCacheDbConnectionString)(BSTR newVal);
	STDMETHOD(get_UseCRLCache)(BOOL* pVal);
	STDMETHOD(put_UseCRLCache)(BOOL newVal);
	STDMETHOD(put_CRLCacheTimeoutInMinutes)(ULONG newVal);
	STDMETHOD(put_CanonicalizationMethod)(ULONG newVal);
	STDMETHOD(get_NetscapeStorePassword)(BSTR* pVal);
	STDMETHOD(put_NetscapeStorePassword)(BSTR newVal);
	STDMETHOD(SetActivePEMFileCert)(BSTR pemFileName, BSTR pemPassword, BSTR* pemX509Cert);
	STDMETHOD(get_SecureXMLPath)(BSTR* pVal);
	STDMETHOD(get_SignedDocumentCount)(LONG sigIndex, LONG* pVal);
};

#endif //__SIGNATURE_H_
