//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XMLSign.rc
//
#define IDS_PROJNAME                    100
#define IDR_SIGNATURE                   101
#define IDC_SIGOK                       101
#define IDR_CERTIFICATE                 102
#define IDS_SIGNEW                      102
#define IDD_SHOWSELECTCERT              103
#define IDI_ICON1                       201
#define IDC_LIST1                       201
#define IDC_LIST2                       202
#define IDC_BUTTON1                     203
#define IDI_ICON2                       204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        210
#define _APS_NEXT_COMMAND_VALUE         500
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
