// ShowSelectCert.h : Declaration of the CShowSelectCert

#ifndef __SHOWSELECTCERT_H_
#define __SHOWSELECTCERT_H_

#include "stdafx.h"
#include "resource.h"       // main symbols
#include <atlhost.h>
#include <winuser.h>


#if __cplusplus
extern "C" {
#endif

#include <libxml/parser.h>
#include <securexml/ax.h>
#include <securexml/errors.h>
#include <securexml/utils.h>
#include <securexml/base64.h>
	#include <securexml/coresig.h>

#if __cplusplus
}
#endif


/////////////////////////////////////////////////////////////////////////////
// CShowSelectCert
class CShowSelectCert : 
	public CAxDialogImpl<CShowSelectCert>
{
public:
//	class CSignature *curSig;
	PCERT_DESCR *cV;
	unsigned char* serialNo;
	//char *issuer[MAX_CERT_COUNT];
	//char* subject[MAX_CERT_COUNT];
	//char* notAfter[MAX_CERT_COUNT];
	//char* decodedDataPtr[MAX_CERT_COUNT];
	char **issuer;
	char **subject;
	char **notAfter;
	char **decodedDataPtr;
	char * certificate;
	int count;
	short nCurrentRow;
	char* getCertificateData(int);
	BOOL certSelected;
	char StoreName[MAX_PATH];
	
	CShowSelectCert()
	{
		
	}
	CShowSelectCert(/*CSignature *curSig,*/ unsigned char *storeName, PCERT_DESCR *cV, long certCount);
	
	virtual ~CShowSelectCert();

	enum { IDD = IDD_SHOWSELECTCERT };

BEGIN_MSG_MAP(CShowSelectCert)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)		
	NOTIFY_HANDLER(IDC_LIST2, NM_CLICK, OnClickList)
	COMMAND_HANDLER(IDC_BUTTON1, BN_CLICKED, OnClickedButton1)		
END_MSG_MAP()

	LRESULT CShowSelectCert::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		if (count != 0)
		{
			//Insert header		
			
			CreateHeader();
			
			// Inserts first Row with four columns .		

			for(int i=0;i<count;i++){		
				SetCell((char *)subject[i],i,0);
				SetCell((char *)issuer[i],i,1);			
				SetCell((char *)notAfter[i],i,2);		
				SetCell((char *)decodedDataPtr[i],i,3);
			}
			CenterWindow();
			nCurrentRow = 0;
			setSelection();

		}
				
		return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		certSelected = TRUE;
		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		certSelected = FALSE;
		EndDialog(wID);
		return 0;
	}
	void CShowSelectCert::CreateHeader()
	{
		CWindow listControl(GetDlgItem(IDC_LIST2));
		
		listControl.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE,LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);

		LVCOLUMN list1;
		list1.mask =  LVCF_TEXT |LVCF_WIDTH| 
        LVCF_FMT |LVCF_SUBITEM;
		list1.fmt = LVCFMT_LEFT;
		
		list1.cx = 100;
		list1.pszText   = "Serial No";
		list1.iSubItem = 0;		
		listControl.SendMessage(LVM_INSERTCOLUMN, (WPARAM)0,(WPARAM)&list1);
		
		list1.cx = 100;
		list1.pszText   = "Expiration Date";
		list1.iSubItem = 1;
		listControl.SendMessage(LVM_INSERTCOLUMN, (WPARAM)0,(WPARAM)&list1);	

		list1.cx = 100;
		list1.pszText   = "Issued by";
		list1.iSubItem = 2;
		listControl.SendMessage(LVM_INSERTCOLUMN, (WPARAM)0,(WPARAM)&list1);
		
		list1.cx = 100;
		list1.pszText   = "Issued To";
		list1.iSubItem = 3;
		listControl.SendMessage(LVM_INSERTCOLUMN, (WPARAM)0,(WPARAM)&list1);
		
		

	}
	void CShowSelectCert::SetCell(char* value, int nRow, int nCol)
	{
    
	CWindow listControl(GetDlgItem(IDC_LIST2));

    //Fill the LVITEM structure with the 
    //values given as parameters.
	
    LVITEM lvItem;
    lvItem.mask = LVIF_TEXT;
    lvItem.iItem = nRow;
    lvItem.pszText = value;
    lvItem.iSubItem = nCol;
	lvItem.lParam = (LPARAM) value;
    if(nCol >0)
        
		ListView_SetItem(listControl.m_hWnd,&lvItem);
		
    else
        //Insert the value into List
        ListView_InsertItem(listControl.m_hWnd,&lvItem);
	}

	LRESULT OnClickList(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
	{		
	
		LPNMITEMACTIVATE temp = (LPNMITEMACTIVATE) pnmh;
		
		nCurrentRow = temp->iItem;	
		
		return 0;
	}
	char *CShowSelectCert::selectCertificate()
	{
		if (count != 0)
			DoModal();
		else
			MessageBox("Please Install PKI Certificate", "No PKI Certificates Found", MB_OK);

		if(certSelected)
			return getCertificateData(nCurrentRow);
		else 
			return NULL;
	}

	void CShowSelectCert::setSelection()
	{
	CWindow listControl(GetDlgItem(IDC_LIST2));
	ListView_SetItemState(listControl, nCurrentRow, LVIS_SELECTED| LVIS_FOCUSED, LVIS_SELECTED| LVIS_FOCUSED); 
	}

	LRESULT OnClickedButton1(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
};

#endif //__SHOWSELECTCERT_H_
