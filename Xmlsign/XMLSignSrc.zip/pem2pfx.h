// pem2pfx.h
//

#include <windows.h>

char *Pem2Pfx(char *pemFile, char *pemPass);
