/*****************************************************************************************
 * Copyright: (c) 2000-2002 Infomosaic Corporation.
 * All rights reserved.
 * It is violation of international law to use this code without proper written authorization
 * and license agreement from Infomosaic Corporation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL INFOMOSAIC CORPORATION  OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * Author: 
 * Date:   
 * Change history:
 *
 * Date		|	Modified By		|	Brief description of the modification
 *
 *
 *****************************************************************************************
 */
#include "stdafx.h"

#include <windows.h>
#include <wincrypt.h>
#include <winldap.h>
#include <winber.h>
#include <stdio.h>
#include <math.h>

extern "C" {
#include <securexml/ax.h>
#include <securexml/cr.h>
#include <securexml/xs.h>
#include <securexml/utils.h>
#include <securexml/base64.h>
#include <securexml/coresig.h>
#include <securexml/errors.h>
}
#include "CertVerify.h"
#include <securexml/DebugLog.h>

//#define MY_TYPE (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING)
static BOOL checkCertificate(PCCERT_CONTEXT pCertContext, 
							 HCERTSTORE hStoreHandle,
							 LPFILETIME pTime, 
							 VERIFICATION_PARAMS *certVerParams,
							 PGLOBAL_SIG pg_sig);

static int check_CRL(HCERTSTORE hStoreHandle,
					 PCCERT_CONTEXT pCertContext, 
					 PCCERT_CONTEXT pIssuerCertContext,
					 CRLCache *pCrlCache,
					 LPSTR *crlAltUrl,
					 UINT	altCrlCount,
					 BOOL	*crlFound,
					 PGLOBAL_SIG pg_sig);

/**
 * crVerifyCertificate
 * @certData: (in) array of base64 encoded PFX or X509 DER/ASN certificate
 * @certNum: (in) number certificates in array
 * @pSysTime:	(in) Time to use for certificate chain verification (optional, if NULL will use system time)
 * @hKey:	(in) PFX password
 * @pg_sig: (in) PGLOBAL_SIG
 *
 * Checks certificate chain, including revocation checking if pg_sig->doCRLCheck = true 
 *
 * Returns: TRUE/FALSE
 */
BOOL crVerifyCertificate(BYTE **certData, 
						 UINT certNum,
						 LPSYSTEMTIME pSysTime, 
						 LPWSTR password, 
						 VERIFICATION_PARAMS *certVerParams,
						 PGLOBAL_SIG pg_sig) {
BYTE *pbCert=NULL;
DWORD cbCert=0;
int err=0;
UINT i=0;
CRYPT_DATA_BLOB pfxBlob;
PCCERT_CONTEXT pct=NULL;
PCCERT_CONTEXT endPct=NULL;
HCERTSTORE hStoreHandle=NULL;
int optFlag =0;
BOOL mustCleanPfx=0;
FILETIME pfTime;
LPFILETIME pTime;
BOOL sysTimeStatus=FALSE;

HCRYPTPROV hProv;
int res=0;
CRYPT_KEY_PROV_INFO *provInfo;
DWORD cbData=0;

//DebugBreak();

if (!certData) {
	return FALSE;
}

if ((certVerParams->userPolicySetCountOut != 0) && 
	(certVerParams->userPolicySetOut != NULL))
{
	for (i=0; i < certVerParams->userPolicySetCountOut; i++)
	{
		if (certVerParams->userPolicySetOut[i] != NULL)
			zFree(certVerParams->userPolicySetOut[i]);
	}
	zFree(certVerParams->userPolicySetOut);
	certVerParams->userPolicySetCountOut = 0;
	certVerParams->userPolicySetOut = NULL;
}
if ((certVerParams->authPolicySetCountOut != 0) && 
	(certVerParams->authPolicySetOut != NULL))
{
	for (i=0; i < certVerParams->authPolicySetCountOut; i++)
	{
		if (certVerParams->authPolicySetOut[i] != NULL)
			zFree(certVerParams->authPolicySetOut[i]);
	}
	zFree(certVerParams->authPolicySetOut);
	certVerParams->authPolicySetCountOut = 0;
	certVerParams->authPolicySetOut = NULL;
}

if (pSysTime!=NULL) {
pTime = &pfTime;
sysTimeStatus = SystemTimeToFileTime(pSysTime, pTime);
} else {
pTime=NULL;
}

for (i=0;i<certNum;i++) {
	pfxBlob.cbData = base64decodeSize(strlen((const char *)certData[i]));
	pfxBlob.pbData = (BYTE *)malloc (pfxBlob.cbData+1);
	memset(pfxBlob.pbData,0x00,pfxBlob.cbData);
	if (base64decode(certData[i],pfxBlob.pbData,pfxBlob.cbData)==-1) {
		setError(pg_sig, BASE64_ERROR);
		err=TRUE; goto retLabel;
	}

// special case: if certNum =1 it may be PFX
	if (certNum==1 && PFXIsPFXBlob(&pfxBlob)) {		
		// check if we have password
		if (!PFXVerifyPassword(&pfxBlob, password, CRYPT_MACHINE_KEYSET))
		{
			setError(pg_sig,PFX_BAD_PASSWORD);
			err=TRUE; goto retLabel;
		}

		if ((hStoreHandle =  PFXImportCertStore(
										&pfxBlob, 
										password, 
										CRYPT_MACHINE_KEYSET | CRYPT_EXPORTABLE
										)) == NULL)
		{
			setError(pg_sig,PFX_IMPORT_FAILED);
			err=TRUE; goto retLabel;
		}
		mustCleanPfx = TRUE;

		// we need CERT_CONTEXT
		while(pct = CertEnumCertificatesInStore(
			 hStoreHandle,
			pct))
		{			
				int optFlag=0;
				if (crFilterCerts(pct,&optFlag,NULL,pg_sig)) 
				{
					cleanupError(pg_sig);
					break;
				}
		}

		if (pct == NULL) {
			setError(pg_sig, PFX_INVALID_CERTIFICATE);
			err=TRUE; goto retLabel;
		}

		if (!checkCertificate(	pct, 
								hStoreHandle, 
								pTime,
								certVerParams,
								pg_sig)) {
			err=TRUE;
		}

		res = CertGetCertificateContextProperty(pct,CERT_KEY_PROV_INFO_PROP_ID,NULL,&cbData);
		if (!res) goto retLabel;
		provInfo = (CRYPT_KEY_PROV_INFO *) zMalloc(cbData);
		if (!provInfo) goto retLabel;
		res = CertGetCertificateContextProperty(pct,CERT_KEY_PROV_INFO_PROP_ID,provInfo,&cbData);
		if (!res) goto retLabel;
		res = CryptAcquireContextW(&hProv, 
							 provInfo->pwszContainerName, 
							 provInfo->pwszProvName, 
							 provInfo->dwProvType, 
							 CRYPT_DELETEKEYSET |(provInfo->dwFlags  & CRYPT_MACHINE_KEYSET));
		zFree(provInfo);
		goto retLabel;
	}
	else {
	// have to add certificate to the store
		if (hStoreHandle == NULL) {
			if(!(hStoreHandle = CertOpenStore(
			CERT_STORE_PROV_MEMORY,   // The memory provider type
			0,                        // The encoding type is not needed
			(HCRYPTPROV) NULL,                     // Use the default HCRYPTPROV
			0,                        // Accept the default dwFlags
			NULL                      // pvPara is not used
			))) {
				setError(pg_sig, CAPI_OPEN_STORE);
				err=TRUE; goto retLabel;
			}
		}

	if(!(CertAddEncodedCertificateToStore(
		hStoreHandle,
		MY_ENCODING_TYPE, // The encoding type
		(const BYTE*) pfxBlob.pbData,   // The encoded data from the certificate retrieved
		pfxBlob.cbData,
		CERT_STORE_ADD_REPLACE_EXISTING,
		&pct	)))  // The length of the encoded data
		{
			setError(pg_sig, CAPI_ADD_CERT);
			err=TRUE; goto retLabel;
		}
	
	if (i==0) endPct = pct;	// end certificate is always the first in array
	else{
		CertFreeCertificateContext(pct);
	}
  } // PFX?
} // for
		
	// certificates now in temp store. Take the end certificate and check it.
	if (!checkCertificate(	endPct, 
		hStoreHandle, 
		pTime,
		certVerParams,
		pg_sig)) {
		err=TRUE;
	}

retLabel:

// cleanup store
if (endPct) CertFreeCertificateContext(endPct);
if (hStoreHandle) {
	CertCloseStore(hStoreHandle,CERT_CLOSE_STORE_FORCE_FLAG);
}

if (pfxBlob.pbData) free (pfxBlob.pbData);
if (err) 
	return FALSE;
else 
	return TRUE;

}

/**
 * Check certificate chain - trust and CRL check
 *
 * !!! TODO: crlAltUrl must be array or URLs rather then single entry
 */
static BOOL checkCertificate(PCCERT_CONTEXT pCertContext,
							 HCERTSTORE hStoreHandle,
							 LPFILETIME pTime, 
							 VERIFICATION_PARAMS *certVerParams,
							 PGLOBAL_SIG pg_sig) {
// chain parameters
CERT_CHAIN_PARA ChainPara;
CERT_ENHKEY_USAGE EnhkeyUsage;
CERT_USAGE_MATCH  CertUsage;  
PCCERT_CHAIN_CONTEXT     pChainContext=NULL;
DWORD dwFlag = 0;
int err=0;
UINT certIndex, issuerIndex;
BOOL checkCRLFailed;
UINT crlCount;
LPSTR *crlList;
BYTE *crlCertUrl=NULL;
LPSTR *authConstPolSet=NULL;
UINT	authConstPolCount=0;
LPSTR *userConstPolSet=NULL;
UINT	userConstPolCount=0;
UINT	explicitPolicyCount;
UINT i;
BOOL trustedRootFound=FALSE;
unsigned char *pbData;
UINT	cbData;
CERT_CONTEXT *pct;
DWORD rootCertIndex;
BOOL crlFound = FALSE;
BOOL result = FALSE;

// create chain 
		EnhkeyUsage.cUsageIdentifier = 0;
		EnhkeyUsage.rgpszUsageIdentifier=NULL;
		CertUsage.dwType = USAGE_MATCH_TYPE_AND;
		CertUsage.Usage  = EnhkeyUsage;
		ChainPara.cbSize = sizeof(CERT_CHAIN_PARA);
		ChainPara.RequestedUsage=CertUsage;

		if ((certVerParams->verificationOptions & VERIFY_CRL) &&
			(certVerParams->altCrlCount == 0))
			dwFlag = CERT_CHAIN_REVOCATION_CHECK_CHAIN;

		if(!CertGetCertificateChain(
			NULL,                  // Use the default chain engine.
			pCertContext,          // Pointer to the end certificate.
			pTime,                 // Use the default time (NULL) or specified
			hStoreHandle,          // Search the temporary store for PFX files.
			&ChainPara,            // Use AND logic, and enhanced key usage 
								   // as indicated in the ChainPara 
								   // data structure.
			dwFlag,
			NULL,                  // Currently reserved.
			&pChainContext))       // Return a pointer to the chain created.
		{
			setError (pg_sig, CAPI_GET_CERT_CHAIN);
			return FALSE;
		}

//DebugBreak();
		if (certVerParams->verificationOptions & EXPLICIT_TRUST)
		{
			if ((certVerParams->trustRootCertCount == 0) ||
				(certVerParams->trustRootCerts == NULL))
			{
#ifdef _DEBUG
				MessageBox(NULL, "trustRootCertCount == 0 || trustRootCerts == NULL", "checkCertificate", MB_OK);
#endif
				setError(pg_sig, CERT_UNTRUSTED_ROOT);
				err=TRUE;
				goto exitCheckCertificate;
			}
			rootCertIndex = pChainContext->rgpChain[0]->cElement - 1;
			for (i=0; i < certVerParams->trustRootCertCount; i++)
			{
				cbData = base64decodeSize(strlen(certVerParams->trustRootCerts[i]));
				pbData = (unsigned char *) malloc (cbData+1);
				if (pbData == NULL)
				{
					setError(pg_sig, MEMORY_FAULT);
					err=TRUE; goto exitCheckCertificate;
				}
				memset(pbData,0x00,cbData);
				cbData = base64decode(	(unsigned char *)certVerParams->trustRootCerts[i],
									pbData,
									cbData);
				if (cbData == -1) 
				{
					setError(pg_sig, BASE64_ERROR);
					zFree(pbData);
					err=TRUE; goto exitCheckCertificate;
				}
				if(!(pct = (CERT_CONTEXT *) CertCreateCertificateContext(
					MY_ENCODING_TYPE  ,            // The encoding type
					pbData,   // The encoded data from the certificate retrieved
					cbData)))  // The length of the encoded data
				{
					setError(pg_sig, CAPI_CREATE_CERT_CNTX);
					zFree(pbData);
					err=TRUE; goto exitCheckCertificate;
				}
				if (CertCompareCertificate(	MY_ENCODING_TYPE,
											pct->pCertInfo,
											pChainContext->rgpChain[0]->rgpElement[rootCertIndex]->pCertContext->pCertInfo
											))
				{
					trustedRootFound = TRUE;
					CertFreeCertificateContext(pct);
					zFree(pbData);
					break;
				}
				CertFreeCertificateContext(pct);
				zFree(pbData);
			}
			if (trustedRootFound == FALSE)
			{
#ifdef _DEBUG
				MessageBox(NULL, "Trusted root not found", "checkCertificate", MB_OK);
#endif
				setError(pg_sig, CERT_UNTRUSTED_ROOT);
				err=TRUE;
				goto exitCheckCertificate;
			}
		}

		if (certVerParams->verificationOptions & VERIFY_CHAIN)
		{
			if (!certIsBasicExtensionConstraintOK(pChainContext, pg_sig))
			{
				setError(pg_sig, BASIC_CONSTRAINT_ERR);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (!certIsKeyUsageOK(pChainContext, pg_sig))
			{
				setError(pg_sig, CERT_KEY_USAGE_ERR);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (!certIsNameChainOK(pChainContext))
			{
				setError(pg_sig, CERT_INVALID_CHAIN);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_NOT_TIME_VALID)
			{
				setError(pg_sig, CERT_TIME_INVALID);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_NOT_TIME_NESTED)
			{
				setError(pg_sig, CERT_TIME_NOT_NESTED);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_NOT_SIGNATURE_VALID)
			{
				setError(pg_sig, CERT_SIGNATURE_INVALID);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_NOT_VALID_FOR_USAGE)
			{
				setError(pg_sig, CERT_INVALID_USAGE);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_UNTRUSTED_ROOT)
			{
				setError(pg_sig, CERT_UNTRUSTED_ROOT);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_CYCLIC)
			{
				setError(pg_sig, CERT_TRUST_CYCLIC);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_PARTIAL_CHAIN)
			{
				setError(pg_sig, CERT_PARTIAL_CHAIN);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_CTL_IS_NOT_TIME_VALID)
			{
				setError(pg_sig, CERT_TIME_INVALID);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID)
			{
				setError(pg_sig, CERT_SIGNATURE_INVALID);
				err = TRUE;
				goto exitCheckCertificate;
			}

			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE)
			{
				setError(pg_sig, CERT_INVALID_USAGE);
				err = TRUE;
				goto exitCheckCertificate;
			}
		}

		if (certVerParams->verificationOptions & VERIFY_PATH_LENGTH)
		{
			if (!certIsPathLengthConstraintOK(pChainContext, pg_sig))
			{
				setError(pg_sig, CERT_PATHLEN_ERR);
				err = TRUE;
				goto exitCheckCertificate;
			}
		}

		if (certVerParams->verificationOptions & VERIFY_POLICY)
		{
//DebugBreak();			
			if (certVerParams->verificationOptions & POLICY_EXPLICIT)
				explicitPolicyCount = 0;
			else
				explicitPolicyCount = pChainContext->rgpChain[0]->cElement + 1;

			certVerParams->authPolicySetOut = getAuthConstrainedPolicySet(pChainContext,
															explicitPolicyCount,
															&certVerParams->explicitPolicyInd,// out
															&certVerParams->authPolicySetCountOut);
			if (certVerParams->verificationOptions & POLICY_EXPLICIT)
			{
				if (certVerParams->authPolicySetCountOut == 0)
				{
					certVerParams->userPolicySetCountOut=0;
					setError(pg_sig, CERT_POLICY_ERROR);
					err = TRUE;
					goto exitCheckCertificate;
				}
			}
			// this function returns Auth Constraint policy set if user policy is ANY
			certVerParams->userPolicySetOut = getUserConstrainedPolicySet(pChainContext,
															certVerParams->userPolicySet,
															certVerParams->userPolicyCount,
															explicitPolicyCount,
															&certVerParams->explicitPolicyInd,		// out
															&certVerParams->userPolicySetCountOut);			

			if ((certVerParams->verificationOptions & POLICY_EXPLICIT) && 
				(certVerParams->userPolicySetCountOut == 0))
			{
				if (certVerParams->userPolicySetCountOut == 0)
				{
					setError(pg_sig, CERT_POLICY_ERROR);
					err = TRUE;
					goto exitCheckCertificate;
				}
			}
			if ((certVerParams->explicitPolicyInd == 0) &&
				(certVerParams->userPolicySetCountOut == 0))
			{
				setError(pg_sig, CERT_POLICY_ERROR);
				err = TRUE;
				goto exitCheckCertificate;
			}
											 
		}

		err=TRUE;

		switch(pChainContext->TrustStatus.dwErrorStatus)
		{
		case CERT_TRUST_NO_ERROR :
			err=FALSE;
			break;
		case CERT_TRUST_IS_NOT_TIME_VALID: 
			break;
		case CERT_TRUST_IS_NOT_TIME_NESTED: 
			break;
		case CERT_TRUST_IS_REVOKED:
			break;
		case CERT_TRUST_IS_NOT_SIGNATURE_VALID:
			setError(pg_sig,CRL_BAD_SIGNATURE);
			break;
		case CERT_TRUST_IS_NOT_VALID_FOR_USAGE:
			break;
		case CERT_TRUST_IS_UNTRUSTED_ROOT:
			break;
		case CERT_TRUST_REVOCATION_STATUS_UNKNOWN:
			break;
		case CERT_TRUST_IS_CYCLIC :
			break;
		case CERT_TRUST_IS_PARTIAL_CHAIN: 
			break;
		case CERT_TRUST_CTL_IS_NOT_TIME_VALID: 
			break;
		case CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID: 
			break;
		case CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE: 
			break;
		case CERT_TRUST_IS_OFFLINE_REVOCATION:
			break;
		default:
			err=TRUE;
			break;
		} // End switch

//DebugBreak();

		if (certVerParams->verificationOptions & VERIFY_CRL)
		{
			if (pChainContext->TrustStatus.dwErrorStatus & CERT_TRUST_IS_REVOKED)
			{
				setError(pg_sig, CRL_CERT_REVOKED);
				err = TRUE;
				goto exitCheckCertificate;
			}

			checkCRLFailed = FALSE;
			for (certIndex=0; certIndex < pChainContext->rgpChain[0]->cElement; certIndex++)
			{
				if (certIndex == pChainContext->rgpChain[0]->cElement - 1)
					issuerIndex = certIndex;
				else
					issuerIndex = certIndex+1;

				if ((certVerParams->altCrlCount != 0) &&
					(certVerParams->crlAltUrl != NULL))//Local CRL Location is given, so use that first
				{
					crlCount = certVerParams->altCrlCount;
					crlList = certVerParams->crlAltUrl;
					result = check_CRL (	hStoreHandle, 
											pChainContext->rgpChain[0]->rgpElement[certIndex]->pCertContext, 
									pChainContext->rgpChain[0]->rgpElement[issuerIndex]->pCertContext,
									certVerParams->pCrlCache,
									crlList,
									crlCount,
									&crlFound,
									pg_sig);
					if (crlFound == TRUE)
					{
						if (result == FALSE) //CRL validation failed for some reason
						{
							checkCRLFailed = TRUE;
							break; // At least one of the certificates in the chain has a problem
						}
						else // CRL validation was successful
						{
							crlFound = FALSE; // reset this boolean for the next certificate in the chain
							checkCRLFailed = FALSE;
							continue; // check the next certificate in the chain
						}
					}
				}
				if ((crlFound == TRUE) && (checkCRLFailed == FALSE)) // The whole chain validated successfully
					break;
				else
				{// CRL was not found in the given CRL Location list. Try certificate CRL DP
//DebugBreak();
					crlCertUrl = getCRLDist(pChainContext->rgpChain[0]->rgpElement[certIndex]->pCertContext);
					if (crlCertUrl == NULL)
					{
						if ( certIndex != 0)
						{
							// If this is the root certificate, then the CRL may be
							// available from the first intermediate certificate
							// since the issuers for both are the root CA
							if (certIndex == pChainContext->rgpChain[0]->cElement - 1)
							{
								crlCertUrl = getCRLDist(pChainContext->rgpChain[0]->rgpElement[certIndex -1]->pCertContext);
								if (crlCertUrl == NULL)
								{//No CRL DP present and none of the given CRL Locations, if any, matched
									crlFound = FALSE;
									checkCRLFailed = TRUE;
									setError(pg_sig, CRL_NOT_FOUND);
									break;
								}
								else
								{// CRL Location Found
									crlCount = 1;
									crlList = (LPSTR *)zMalloc(sizeof (char *));
									crlList[0] = (LPSTR)crlCertUrl;
								}
							}
							else
							{//No CRL DP present and none of the given CRL Locations, if any, matched
								crlFound = FALSE;
								checkCRLFailed = TRUE;
								setError(pg_sig, CRL_NOT_FOUND);
								break;
							}
						}
						else
						{//No CRL DP present and none of the given CRL Locations, if any, matched
							crlFound = FALSE;
							checkCRLFailed = TRUE;
							setError(pg_sig, CRL_NOT_FOUND);
							break;
						}
					}
					else
					{// CRL Location Found
						crlCount = 1;
						crlList = (LPSTR *)zMalloc(sizeof (char *));
						crlList[0] = (LPSTR)crlCertUrl;
					}

					result = check_CRL (hStoreHandle,
										pChainContext->rgpChain[0]->rgpElement[certIndex]->pCertContext, 
									pChainContext->rgpChain[0]->rgpElement[issuerIndex]->pCertContext,
									certVerParams->pCrlCache,
									crlList,
									crlCount,
									&crlFound,
									pg_sig);
					if (crlFound == TRUE)
					{
						if (result == FALSE) //CRL validation failed for some reason
						{
							checkCRLFailed = TRUE;
							zFree(crlCertUrl);
							free (crlList);
							break; // At least one of the certificates in the chain has a problem
						}
						else // CRL validation was successful
						{
							crlFound = FALSE; // reset this boolean for the next certificate in the chain
							zFree(crlCertUrl);
							free (crlList);
							continue; // check the next certificate in the chain
						}
					}
					else
					{	//No CRL DP present and none of the given CRL Locations, if any, matched
						crlFound = FALSE;
						checkCRLFailed = TRUE;
						zFree(crlCertUrl);
						free (crlList);
						break;
					}
				}
			}
			if (checkCRLFailed == FALSE)
				err = FALSE;
			else
				err = TRUE;
		}

exitCheckCertificate:
		CertFreeCertificateChain(pChainContext);

		if (err) {
//			setError(pg_sig,CERT_TRUST_ERROR);
			return FALSE;
		} else {
			return TRUE;
		}
}

/**
 * Alternative procedure to verify certificate against CRL.
 * CRL URL can be ldap, http or file. In file case it is simply file name, no prefixes.
 *
 * Returns: TRUE/FALSE, TRUE if CRL fetched, validated and doesn't contain certificate serial.
 *			FALSE if CRL cannot be fetched or CRL contains certificate serial.
 */
static int check_CRL(HCERTSTORE hStoreHandle,
					 PCCERT_CONTEXT pCertContext, 
					 PCCERT_CONTEXT pIssuerCertContext, 
					 CRLCache *pCrlCache,
					 LPSTR *crlAltUrl,
					 UINT	altCrlCount,
					 BOOL	*crlFound,
					 PGLOBAL_SIG pg_sig) {
	BYTE *crlUrl=NULL;
	PCCRL_CONTEXT pCrlContext=NULL;
	PCRL_ENTRY pCrlEntry = (PCRL_ENTRY) zMalloc(sizeof(CRL_ENTRY));
	PCRL_ENTRY *ppCrlEntry = &pCrlEntry;
	int ret=TRUE;
	PDS_DATA_BLOB crl=NULL;
	PDS_DATA_BLOB *crlDataList=NULL;
	UINT crlCount=0;
	UINT crlIndex;
	BOOL validCrlFound = FALSE;

//DebugBreak();
	if (pCrlCache != NULL)
	{
		crlDataList = pCrlCache->FetchCRLFromCRLCache(	&pCertContext->pCertInfo->Issuer,
														&crlCount,
														pg_sig);
		if ((crlCount != 0) && (crlDataList != NULL))
		{// A CRL was found in the CRL Cache
			for (crlIndex=0; crlIndex < crlCount; crlIndex++)
			{
				crl = crlDataList[crlIndex];
				// create CRL context
				pCrlContext = CertCreateCRLContext(MY_TYPE,crl->pbData,crl->cbData);
				if (pCrlContext==NULL) 
				{
					cleanupError(pg_sig); // Remove all previous errors from the error stack
					setError(pg_sig,CRL_ERROR);
					ret=FALSE;
					continue;
				}
				// Check to see if the CRL issuer and the certificate issuers are the same
				if (certIsNameEqual(&pCertContext->pCertInfo->Issuer, 	&pCrlContext->pCrlInfo->Issuer) 
						== TRUE) // certificate and CRL issuers match
				{
					validCrlFound = TRUE;
					if (!CryptVerifyCertificateSignature(
						(HCRYPTPROV) NULL,	// CSP
						MY_TYPE,
						pCrlContext->pbCrlEncoded,	
						pCrlContext->cbCrlEncoded,
						&pIssuerCertContext->pCertInfo->SubjectPublicKeyInfo))
					{
						cleanupError(pg_sig); // Remove all previous errors from the error stack
						setError(pg_sig,CRL_BAD_SIGNATURE);
						ret=FALSE;
						CertFreeCRLContext(pCrlContext);
						pCrlContext = NULL;
						continue;
					}
					else // CRL has a valid signature from the cert issuer
					{
						PCERT_EXTENSION  pCertExtInfo = NULL;
						*crlFound = TRUE;
						pCertExtInfo = CertFindExtension(	szOID_DELTA_CRL_INDICATOR,
															pCrlContext->pCrlInfo->cExtension,
															pCrlContext->pCrlInfo->rgExtension);
						if (pCertExtInfo != NULL)
						{
							validCrlFound = FALSE; // Set CRL Found to false in order to force a CRL Fetch
							pCrlCache->DeleteCRLFromCRLCache(&pCertContext->pCertInfo->Issuer, crl, pg_sig);

							setError(pg_sig, CRL_ERROR);
							ret=FALSE;
							CertFreeCRLContext(pCrlContext);
							pCrlContext = NULL;
							break;
						}
						
						pCertExtInfo = CertFindExtension(	szOID_ISSUING_DIST_POINT,
															pCrlContext->pCrlInfo->cExtension,
															pCrlContext->pCrlInfo->rgExtension);
						if (pCertExtInfo != NULL)
						{
							validCrlFound = FALSE; // Set CRL Found to false in order to force a CRL Fetch
							pCrlCache->DeleteCRLFromCRLCache(&pCertContext->pCertInfo->Issuer, crl, pg_sig);

							setError(pg_sig, CRL_ERROR);
							ret=FALSE;
							CertFreeCRLContext(pCrlContext);
							pCrlContext = NULL;
							break;
						}
						if (!CertFindCertificateInCRL(pCertContext,pCrlContext,0,0,ppCrlEntry)) 
						{
							// list wasn't searched
							cleanupError(pg_sig); // Remove all previous errors from the error stack
							setError(pg_sig,CRL_ERROR);
							ret=FALSE;
							CertFreeCRLContext(pCrlContext);
							pCrlContext = NULL;
							continue;
						}
						//Add this to the Store for faster validation in the future
						CertAddCRLContextToStore(hStoreHandle, pCrlContext,CERT_STORE_ADD_NEWER,NULL);

						if (pCrlEntry!=NULL) {
							// CRL contains this certificate
							cleanupError(pg_sig); // Remove all previous errors from the error stack
							setError(pg_sig,CRL_CERT_REVOKED);
							ret=FALSE;
							CertFreeCRLContext(pCrlContext);
							pCrlContext = NULL;
							break;
						}
					}// CRL has a valid signature from the cert issuer
					if (CertVerifyCRLTimeValidity(NULL, pCrlContext->pCrlInfo) == 1)
					{
						cleanupError(pg_sig); // Remove all previous errors from the error stack

						validCrlFound = FALSE; // Set CRL Found to false in order to force a CRL Fetch
						pCrlCache->DeleteCRLFromCRLCache(&pCertContext->pCertInfo->Issuer, crl, pg_sig);

						setError(pg_sig,CRL_TOO_OLD);
						ret=FALSE;
						CertFreeCRLContext(pCrlContext);
						pCrlContext = NULL;
						break;
					}
				}//CRL issuer and cert issuers are the same
				else // This CRL is not relevant since it's issuer is not the same as the certificate issuer
				{
					CertFreeCRLContext(pCrlContext);
					pCrlContext = NULL;
					if (crl->pbData) 
						zFree(crl->pbData);
					free (crl);
					crl = NULL;
					continue;
				}
			}//for (crlIndex=0; crlIndex < crlCount; crlIndex++)
			for (int i=0; i<crlCount; i++)
			{
				if (crlDataList[i] != NULL)
				{
					if (crlDataList[i]->pbData != NULL)
						zFree(crlDataList[i]->pbData);
					zFree(crlDataList[i]);
				}
			}
			zFree(crlDataList);
		}//if ((crlCount != 0) && (crlDataList != NULL))
	}//pCrlCache!=NULL

	if (validCrlFound == FALSE)
	{
		for (crlIndex=0; crlIndex < altCrlCount; crlIndex++)
		{
			crlUrl = (BYTE *) crlAltUrl[crlIndex];
			if (!crlUrl) 
				continue;

			if (strncmp((const char *)crlUrl,"ldap:",5)==0) 
			{
				crl = fetchLDAP_URL(crlUrl);
			}
			else
			{
				crl = fetch_URL(crlUrl);
			}
			if (crl==NULL) {
				cleanupError(pg_sig); // Remove all previous errors from the error stack
				ret=FALSE;
				continue;
			}
			// create CRL context
			pCrlContext = CertCreateCRLContext(MY_TYPE,crl->pbData,crl->cbData);
			if (pCrlContext==NULL) 
			{
				cleanupError(pg_sig); // Remove all previous errors from the error stack
				setError(pg_sig,CRL_ERROR);
				ret=FALSE;
				if (crl->pbData) 
					zFree(crl->pbData);
				free (crl);
				crl = NULL;
				continue;
			}
			if (pCrlCache != NULL)
			{
				//Enter CRL into the CRL Cache
				pCrlCache->EnterCRLIntoCRLCache(&pCrlContext->pCrlInfo->Issuer,crl, pg_sig);
			}
			// Check to see if the CRL issuer and the certificate issuers are the same
			if (certIsNameEqual(&pCertContext->pCertInfo->Issuer, 	&pCrlContext->pCrlInfo->Issuer) 
					== TRUE) // certificate and CRL issuers match
			{
				validCrlFound = TRUE;
				if (!CryptVerifyCertificateSignature(
					(HCRYPTPROV) NULL,	// CSP
					MY_TYPE,
					pCrlContext->pbCrlEncoded,	
					pCrlContext->cbCrlEncoded,
					&pIssuerCertContext->pCertInfo->SubjectPublicKeyInfo))
				{
					cleanupError(pg_sig); // Remove all previous errors from the error stack
					setError(pg_sig,CRL_BAD_SIGNATURE);
					ret=FALSE;
					CertFreeCRLContext(pCrlContext);
					pCrlContext = NULL;
					if (crl->pbData) 
						zFree(crl->pbData);
					free (crl);
					crl = NULL;
					continue;
				}
				else // CRL has a valid signature from the cert issuer
				{
					PCERT_EXTENSION  pCertExtInfo = NULL;
					*crlFound = TRUE;
					pCertExtInfo = CertFindExtension(	szOID_DELTA_CRL_INDICATOR,
														pCrlContext->pCrlInfo->cExtension,
														pCrlContext->pCrlInfo->rgExtension);
					if (pCertExtInfo != NULL)
					{
						setError(pg_sig, CRL_ERROR);
						ret=FALSE;
						CertFreeCRLContext(pCrlContext);
						pCrlContext = NULL;
						if (crl->pbData) 
							zFree(crl->pbData);
						free (crl);
						crl = NULL;
						break;
					}
					
					pCertExtInfo = CertFindExtension(	szOID_ISSUING_DIST_POINT,
														pCrlContext->pCrlInfo->cExtension,
														pCrlContext->pCrlInfo->rgExtension);
					if (pCertExtInfo != NULL)
					{
						setError(pg_sig, CRL_ERROR);
						ret=FALSE;
						CertFreeCRLContext(pCrlContext);
						pCrlContext = NULL;
						if (crl->pbData) 
							zFree(crl->pbData);
						free (crl);
						crl = NULL;
						break;
					}
					if (!CertFindCertificateInCRL(pCertContext,pCrlContext,0,0,ppCrlEntry)) 
					{
						// list wasn't searched
						cleanupError(pg_sig); // Remove all previous errors from the error stack
						setError(pg_sig,CRL_ERROR);
						ret=FALSE;
						CertFreeCRLContext(pCrlContext);
						pCrlContext = NULL;
						if (crl->pbData) 
							zFree(crl->pbData);
						free (crl);
						crl = NULL;
						continue;
					}
					//Add this to the Store for faster validation in the future
					CertAddCRLContextToStore(hStoreHandle, pCrlContext,CERT_STORE_ADD_NEWER,NULL);

					if (pCrlEntry!=NULL) {
						// CRL contains this certificate
						cleanupError(pg_sig); // Remove all previous errors from the error stack
						setError(pg_sig,CRL_CERT_REVOKED);
						ret=FALSE;
						CertFreeCRLContext(pCrlContext);
						pCrlContext = NULL;
						if (crl->pbData) 
							zFree(crl->pbData);
						free (crl);
						crl = NULL;
						break;
					}
				}
				if (CertVerifyCRLTimeValidity(NULL, pCrlContext->pCrlInfo) == 1)
				{
					cleanupError(pg_sig); // Remove all previous errors from the error stack
					setError(pg_sig,CRL_TOO_OLD);
					ret=FALSE;
					CertFreeCRLContext(pCrlContext);
					pCrlContext = NULL;
					if (crl->pbData) 
						zFree(crl->pbData);
					free (crl);
					crl = NULL;
					break;
				}
			}
			else // This CRL is not relevant since it's issuer is not the same as the certificate issuer
			{
				CertFreeCRLContext(pCrlContext);
				pCrlContext = NULL;
				if (crl->pbData) 
					zFree(crl->pbData);
				free (crl);
				crl = NULL;
				continue;
			}
		}
	}
	if (!(validCrlFound))
	{
		setError(pg_sig,CRL_NOT_FOUND);
		ret=FALSE;
	}
	return ret;
}
