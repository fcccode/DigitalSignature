import java.io.*;
import java.net.*;


public class LibLoader {
  String dll = null;
  String osVersion = null;
  String osName = null;
  String libraryURL = "http://www.infomosaic.net/XMLSign.dll";

  public LibLoader() {
  }

  public void init(String osName,String osVersion) throws Exception{
    this.osVersion = osVersion;
    this.osName = osName;
    try {
      String libLocation = System.getProperty("java.home");
      libLocation += File.separator;
      libLocation += "XMLSign.dll";

      File f = new File(libLocation);
      boolean mustload = true;
      if (f.exists()) {
//
// Here must be some logic to check if this is the latest version.
// For example, check the file size. I assume that browser will
// download fresh version of the applet which knows about the size of the latest
// ActiveX.
//
        if (f.length() != 800000) {
          f.delete();
        }
        else {
          mustload = false;
        }
      }
      if (mustload) {
        // get the library from URL
        downloadLibrary(libLocation);
      }

//
// Now load it into the memory
//

      System.loadLibrary("XMLSign");


    }catch(Exception e){
      e.printStackTrace();
      throw e;
    }
  }

  private void downloadLibrary(String fileName) throws Exception {
  // try to create a file
    File f = new File(fileName);
    if (f.exists()) {
      f.delete();
    }
    FileOutputStream fos = new FileOutputStream(f);

    if (libraryURL==null) {
      throw new Exception("Library URL is null");
    }

    URL u = new URL(libraryURL);
    HttpURLConnection huc = (HttpURLConnection) u.openConnection();
    huc.setRequestMethod("GET");
    huc.connect();
    InputStream is = huc.getInputStream();
    int code = huc.getResponseCode();
    if (code >= 200 && code < 300) {
      byte[] buf = new byte[2400];
      int l = 0;
      while ((l = is.read(buf))>0) {
        fos.write(buf,0,l);
      }
    }
    fos.close();
    huc.disconnect();
  }

}
