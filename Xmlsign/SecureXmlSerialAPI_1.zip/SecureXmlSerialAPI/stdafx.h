// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <iostream>
#include <tchar.h>
#include <sys/types.h>
//#include <oaidl.h>
#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>
#include <atlwin.h>
#include <commctrl.h>
#include <windows.h>
#include <oleacc.h>
#include <atltime.h>


// TODO: reference additional headers your program requires here
