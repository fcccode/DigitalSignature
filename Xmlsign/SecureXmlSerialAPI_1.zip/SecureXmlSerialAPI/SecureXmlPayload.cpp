#include "stdafx.h"

#include "securexmlpayload.h"
#include <securexml/DebugLog.h>
#include ".\securexmlpayload.h"

extern unsigned char * HeapW2A(BSTR bstrStr);


BSTR * GetBstrArrayFromVariant(VARIANT fileList, UINT *itemCount)
{
	VARIANT **vA;
	UINT arrayDim, elementSize;
	long lBound, uBound;
	VARTYPE arrayType;
	long elementCount;
	BSTR	*bstrList = NULL;
	BSTR	tmpBstr;
	VARIANT *fList;
	BSTR tmpCcBstr;
	UINT numElements=0;

//USES_CONVERSION;
	EnterLog;
	fList = &fileList;
	*itemCount = 0;

	if (fileList.vt == 0x400c)
	{
		fList = fileList.pvarVal;
	}

	if (fList->vt == VT_BSTR) // This is just a BSTR so there is just one file being signed
	{
		tmpCcBstr = fList->bstrVal;
		if (SysStringLen(tmpCcBstr) == 0)
		{
			*itemCount = 0;
			goto getBstrArrayExit;
		}
		else
		{
			*itemCount = 1;
			bstrList = (BSTR *) zMalloc (sizeof(BSTR *));
			bstrList[0] = SysAllocString(fList->bstrVal);
		}
	}
	else
	{
		if (fList->vt & VT_ARRAY)
		{
			if (fList->vt & VT_BYREF)
			{
				arrayDim = SafeArrayGetDim(*(fList->pparray));
				SafeArrayGetLBound(*(fList->pparray), 1,  &lBound);
				SafeArrayGetUBound(*(fList->pparray), 1,  &uBound);
				SafeArrayGetVartype(*(fList->pparray), &arrayType);
				if (arrayType & VT_VARIANT)
				{
					vA = (VARIANT **)zMalloc(sizeof(VARIANT *) * (uBound - lBound + 1));
					for (elementCount=lBound; elementCount <= uBound; elementCount++)
					{
						elementSize = SafeArrayGetElemsize( *(fList->pparray));
						vA[elementCount - lBound]	= (VARIANT *)zMalloc(elementSize);
						SafeArrayGetElement(*(fList->pparray), &elementCount, vA[elementCount - lBound]);
					}
					bstrList = (BSTR *) zMalloc (sizeof(BSTR *) * (uBound - lBound + 1));
					memset((void *)bstrList, 0, sizeof(BSTR *) * (uBound - lBound + 1));
					for (elementCount=lBound; elementCount <= uBound; elementCount++)
					{
						tmpCcBstr = vA[elementCount - lBound]->bstrVal;
						if (SysStringLen(tmpCcBstr) == 0)
						{
							continue;
						}
						else
						{
							bstrList[numElements] = SysAllocString(vA[elementCount - lBound]->bstrVal);
							numElements++;
						}
					}
					for (elementCount=lBound; elementCount <= uBound; elementCount++)
					{
						VariantClear(vA[elementCount - lBound]);
						zFree(vA[elementCount - lBound]);
					}
					zFree(vA);
					*itemCount = numElements;
				}
			}
			else
			{
				arrayDim = SafeArrayGetDim(fList->parray);
				SafeArrayGetLBound(fList->parray, 1,  &lBound);
				SafeArrayGetUBound(fList->parray, 1,  &uBound);
				SafeArrayGetVartype(fList->parray, &arrayType);
				if (arrayType == VT_BSTR)
				{
					bstrList = (BSTR *) zMalloc (sizeof(BSTR *) * (uBound - lBound + 1));
					memset((void *)bstrList, 0, sizeof(BSTR *) * (uBound - lBound + 1));
					for (elementCount=lBound; elementCount <= uBound; elementCount++)
					{
						SafeArrayGetElement(fList->parray, &elementCount, &tmpBstr);
						tmpCcBstr = tmpBstr;
						if (SysStringLen(tmpCcBstr) == 0)
						{
							continue;
						}
						else
						{
							bstrList[numElements] = SysAllocString(tmpBstr);
							numElements++;
						}
					}
					*itemCount = numElements;
				}
				else if (arrayType == VT_VARIANT)
					{
						vA = (VARIANT **)zMalloc(sizeof(VARIANT *) * (uBound - lBound + 1));
						for (elementCount=lBound; elementCount <= uBound; elementCount++)
						{
							elementSize = SafeArrayGetElemsize( fList->parray);
							vA[elementCount - lBound]	= (VARIANT *)zMalloc(elementSize);
							SafeArrayGetElement(fList->parray, &elementCount, vA[elementCount - lBound]);
						}
						bstrList = (BSTR *) zMalloc (sizeof(BSTR *) * (uBound - lBound + 1));
						memset((void *)bstrList, 0, sizeof(BSTR *) * (uBound - lBound + 1));
						for (elementCount=lBound; elementCount <= uBound; elementCount++)
						{
							tmpCcBstr = vA[elementCount - lBound]->bstrVal;
							if (SysStringLen(tmpCcBstr) == 0)
							{
								continue;
							}
							else
							{
								bstrList[numElements] = SysAllocString(vA[elementCount - lBound]->bstrVal);
								numElements++;
							}
						}
						for (elementCount=lBound; elementCount <= uBound; elementCount++)
						{
							VariantClear(vA[elementCount - lBound]);
							zFree(vA[elementCount - lBound]);
						}
						zFree(vA);
						*itemCount = numElements;
					}
			}
		}
	}
getBstrArrayExit:
	ExitLog;
	return bstrList;
}


SecureXmlPayload::SecureXmlPayload(void)
: ApiName(NULL)
, SourceProcessId(0)
, Nonce(NULL)
, SignatureObjectId(0)
, ParamCount(0)
{
	EnterLog;
	doc = NULL;
	charXmlDocPtr = NULL;
	memset(ValueArray, 0, sizeof(char *)*MAXPARAMCOUNT*MAXVALUECOUNT);
	ParamIsArrayArray = NULL;
	ParamArraySizeArray = NULL;
	ParamTypeArray = NULL;
	for (int i=0; i < MAXPARAMCOUNT; i++)
		VariantInit(&VariantParamValue[i]);
	ExitLog;
}

SecureXmlPayload::SecureXmlPayload(const char *apiName, long sourceProcessId, const char *nonce,
					unsigned long signatureObjectId, int paramCount)
{
	EnterLog;
	SetApiName(apiName);
	SetSourceProcessId(sourceProcessId);
	SetNonce(nonce);
	SetSignatureObjectId(signatureObjectId);
	SetParamCount(paramCount);
	ExitLog;
}

SecureXmlPayload::~SecureXmlPayload(void)
{
	EnterLog;
	Reset();
	ExitLog;
}


// Valid input for dataType are String, Integer, ShortInteger and Byte. isArray must be true and arraySize must be 1 if dataType is Byte.
int SecureXmlPayload::SetParamType(int paramIndex, char * dataType, bool isArray, int arraySize)
{
	EnterLog;
	if (paramIndex < ParamCount)
	{
		strcpy(ParamTypeArray[paramIndex].paramType, (const char *)dataType);
		ParamIsArrayArray[paramIndex] = isArray;
		if (!isArray)
			ParamArraySizeArray[paramIndex] = 1;
		else
			ParamArraySizeArray[paramIndex] = arraySize;

	}
	ExitLog;
	return 0;
}

char * SecureXmlPayload::GetParamType(int paramIndex, bool *isArray, int *arraySize)
{
	EnterLog;
	*isArray = ParamIsArrayArray[paramIndex];
	*arraySize = ParamArraySizeArray[paramIndex];
	ExitLog;
	return ParamTypeArray[paramIndex].paramType;
}


int SecureXmlPayload::SetParamValue(int paramIndex, int valueIndex, char * paramValue)
{
	EnterLog;
	if (paramIndex < ParamCount)
	{
		if (valueIndex < ParamArraySizeArray[paramIndex])
		{
			ValueArray[paramIndex][valueIndex] = (char *)zMalloc(strlen(paramValue) + 1);
			strcpy(ValueArray[paramIndex][valueIndex], paramValue);
			if (valueIndex == (ParamArraySizeArray[paramIndex] - 1))
			{
				VARIANT *outVariant;
				SAFEARRAY *outArray;
				SAFEARRAYBOUND rgsabound[1];
				HRESULT hr;
				
				outVariant = (VARIANT *)&VariantParamValue[paramIndex];

				VariantInit(outVariant);
				rgsabound[0].lLbound = 0;
				rgsabound[0].cElements = ParamArraySizeArray[paramIndex];

				outArray = SafeArrayCreate(VT_BSTR, 
											1,
											rgsabound);
				if (outArray == NULL)
				{
					return false;
				}
				for (long i=0; i<(long)ParamArraySizeArray[paramIndex]; i++)
				{
					BSTR arrElement;
					arrElement = A2WBSTR((LPCSTR)GetParamValue(paramIndex, i));
					hr = SafeArrayPutElement(outArray, &i, arrElement);
					if (hr != S_OK)
					{
						return false;
					}
				}
				(*outVariant).vt = (VT_ARRAY | VT_BSTR);
				(*outVariant).parray = outArray;
			}
		}
	}
	ExitLog;
	return 0;
}

char *SecureXmlPayload::GetParamValue(int paramIndex, int valueIndex)
{
	EnterLog;
	if (paramIndex < ParamCount)
	{
		if (valueIndex < ParamArraySizeArray[paramIndex])
		{
			ExitLog;
			return ValueArray[paramIndex][valueIndex];
		}
	}
	ExitLog;
	return NULL;
}

int SecureXmlPayload::SetParamValue(int paramIndex, VARIANT paramValue)
{
	UINT itemCount=0;
	BSTR	*bstrList=NULL;

	EnterLog;
	if (paramIndex < ParamCount)
	{
		VariantParamValue[paramIndex] = paramValue;
		bstrList = GetBstrArrayFromVariant(paramValue, &itemCount);
		ParamArraySizeArray[paramIndex] = itemCount;
		for (int itemIndex=0; itemIndex < itemCount; itemIndex++)
		{
			ValueArray[paramIndex][itemIndex] = (char *)HeapW2A(bstrList[itemIndex]);
			SysFreeString(bstrList[itemIndex]);
		}
		zFree(bstrList);
	}
	ExitLog;
	return 0;
}

VARIANT SecureXmlPayload::GetParamValue(int paramIndex)
{
	VARIANT v;
	VariantInit(&v);
	EnterLog;
	if (paramIndex < ParamCount)
	{
		ExitLog;
		return VariantParamValue[paramIndex];
	}
	ExitLog;
	return v;
}

void SecureXmlPayload::SetApiName(const char * apiName)
{
	EnterLog;
	if (ApiName != NULL)
		zFree(ApiName);
	ApiName = (char *)zMalloc(strlen(apiName) + 1);
	strcpy(ApiName, apiName);
	ExitLog;
}

void SecureXmlPayload::SetSourceProcessId(long sourceProcessId)
{
	EnterLog;
	SourceProcessId = sourceProcessId;
	ExitLog;
}

void SecureXmlPayload::SetNonce(const char * nonce)
{
	EnterLog;
	if (Nonce != NULL)
		zFree(Nonce);
	Nonce = (char *)zMalloc(strlen(nonce) + 1);
	strcpy(Nonce, nonce);
	ExitLog;
}

void SecureXmlPayload::SetSignatureObjectId(unsigned long sigObjId)
{
	EnterLog;
	SignatureObjectId = sigObjId;
	ExitLog;
}

void SecureXmlPayload::SetParamCount(int paramCount)
{
	EnterLog;
	for (int i=0; i<ParamCount; i++)
	{
		if (ParamArraySizeArray != NULL)
			for (int j=0; j<ParamArraySizeArray[i]; j++)
			{
				if (ValueArray[i][j] != NULL)
					zFree(ValueArray[i][j]);
				ValueArray[i][j] = NULL;
			}
	}

	ParamCount = paramCount;

	if (ParamArraySizeArray != NULL)
		zFree(ParamArraySizeArray);
	ParamArraySizeArray = (int *)zMalloc(sizeof(int) * paramCount);
	memset(ParamArraySizeArray, 0, sizeof(int) * paramCount);

	if (ParamIsArrayArray != NULL)
		zFree(ParamIsArrayArray);
	ParamIsArrayArray = (bool *)zMalloc(sizeof(bool) * paramCount);
	memset(ParamIsArrayArray, 0, sizeof(bool) * paramCount);

	if (ParamTypeArray != NULL)
		zFree(ParamTypeArray);
	ParamTypeArray = (ParamTypeNamePtr)zMalloc(sizeof(ParamTypeName) * paramCount);
	memset(ParamTypeArray, 0, sizeof(ParamTypeName) * paramCount);
	ExitLog;
}

void SecureXmlPayload::Reset(void)
{
	EnterLog;
	for (int i=0; i<ParamCount; i++)
	{
		if (ParamArraySizeArray != NULL)
			for (int j=0; j<ParamArraySizeArray[i]; j++)
			{
				if (ValueArray[i][j] != NULL)
					zFree(ValueArray[i][j]);
				ValueArray[i][j] = NULL;
			}
		VariantClear(&VariantParamValue[i]);
		VariantInit(&VariantParamValue[i]);
	}

	if (ApiName != NULL)
		zFree(ApiName);
	ApiName = NULL;

	SourceProcessId = 0;

	if (Nonce != NULL)
		zFree(Nonce);
	Nonce = NULL;

	SignatureObjectId = 0;
	ParamCount = 0;

	if (doc != NULL)
		xmlFreeDoc(doc);
	doc = NULL;

	if (charXmlDocPtr != NULL)
		xmlFree(charXmlDocPtr);
	charXmlDocPtr = NULL;

	if (ParamArraySizeArray != NULL)
		zFree(ParamArraySizeArray);
	ParamArraySizeArray = NULL;

	if (ParamIsArrayArray != NULL)
		zFree(ParamIsArrayArray);
	ParamIsArrayArray = NULL;

	if (ParamTypeArray != NULL)
		zFree(ParamTypeArray);
	ParamTypeArray = NULL;
	ExitLog;
}

char * SecureXmlPayload::GetPayloadXml(unsigned long * xmlByteSize)
{
	EnterLog;
	bool result = CreatePayloadXml();
	if ((result) && (doc != NULL))
	{
		if (charXmlDocPtr != NULL)
			xmlFree(charXmlDocPtr);
		xmlDocDumpMemory(doc,&charXmlDocPtr,&charXmlDocSize);
		*xmlByteSize = charXmlDocSize;
		ExitLog;
		return (char *) charXmlDocPtr;
	}
	else
	{
		ExitLog;
		return NULL;
	}
}

bool SecureXmlPayload::SetPayloadXml(const char * payloadXml)
{
	EnterLog;
	bool result = ParsePayloadXml(payloadXml);
	ExitLog;
	return result;
}

bool SecureXmlPayload::ParsePayloadXml(const char *secureXML_Payload)
{
	EnterLog;
	if (doc != NULL)
		xmlFreeDoc(doc);
	doc = xmlParseMemory((const char *)secureXML_Payload,(int) strlen((const char *)secureXML_Payload));
	xmlNodePtr root = xmlDocGetRootElement(doc);
	xmlNodePtr cur = root->xmlChildrenNode;
	xmlNodePtr parent = cur;
	xmlNodePtr cur1=NULL, cur2=NULL;
	for (; cur != NULL; cur = cur->next)
	{
		if (!(xmlStrcmp(cur->name, (const xmlChar *) "SourceProcess_Id"))) 
		{
			char *sourceProcessId = (char *)xmlNodeListGetString(doc, cur->xmlChildrenNode, 1);
			SetSourceProcessId(atoi(sourceProcessId));
			xmlFree(sourceProcessId);
		}
		if (!(xmlStrcmp(cur->name, (const xmlChar *) "Nonce"))) 
		{
			char *nonce = (char *)xmlNodeListGetString(doc, cur->xmlChildrenNode, 1);
			SetNonce((const char *)nonce);
			xmlFree(nonce);
		}
		if (!(xmlStrcmp(cur->name, (const xmlChar *) "SignatureObject_Id"))) 
		{
			char *signatureObjectId = (char *)xmlNodeListGetString(doc, cur->xmlChildrenNode, 1);
			SetSignatureObjectId((unsigned long)atoi(signatureObjectId));
			xmlFree(signatureObjectId);
		}
		if (!(xmlStrcmp(cur->name, (const xmlChar *) "API"))) 
		{
			parent = cur;
			cur1 = cur->children;
			int paramIndex = 0;
			for (; cur1 != NULL; cur1 = cur1->next)
			{
				if (!(xmlStrcmp(cur1->name, (const xmlChar *)"API_Name")))
				{
					char *apiName = (char *)xmlNodeListGetString(doc, cur1->xmlChildrenNode, 1);
					SetApiName((const char *)apiName);
					xmlFree(apiName);
				}
				if (!(xmlStrcmp(cur1->name, (const xmlChar *)"Param_Count")))
				{
					char *paramCount = (char *)xmlNodeListGetString(doc, cur1->xmlChildrenNode, 1);
					SetParamCount(atoi((const char *)paramCount));
					xmlFree(paramCount);
				}
				if (!(xmlStrcmp(cur1->name, (const xmlChar *)"Param")))
				{
					char *paramType = (char *)xmlGetProp(cur1, (const xmlChar *)"Type");
					char *charArraySize = (char *)xmlGetProp(cur1, (const xmlChar *)"ArraySize");
					int arraySize = 0;
					bool isArray = false;
					if (charArraySize != NULL)
					{
						arraySize = atoi((const char *)charArraySize);
						if (arraySize != 0)
							isArray = true;
					}
					SetParamType(paramIndex, paramType, isArray, arraySize);
					xmlFree(paramType);
					xmlFree(charArraySize);
					int valueIndex = 0;
					cur2 = cur1->children;
					for (; (cur2 != NULL) && (valueIndex < arraySize); cur2 = cur2->next)
					{
						if (!(xmlStrcmp(cur2->name, (const xmlChar *)"Value")))
						{
							char *value = (char *)xmlNodeListGetString(doc, cur2->xmlChildrenNode, 1);
							SetParamValue(paramIndex, valueIndex, value);
							xmlFree(value);
							valueIndex++;
						}
					}
					VARIANT *outVariant;
					SAFEARRAY *outArray;
					SAFEARRAYBOUND rgsabound[1];
					HRESULT hr;
					
					outVariant = (VARIANT *)&VariantParamValue[paramIndex];

					VariantInit(outVariant);
					rgsabound[0].lLbound = 0;
					rgsabound[0].cElements = arraySize;

					outArray = SafeArrayCreate(VT_BSTR, 
												1,
												rgsabound);
					if (outArray == NULL)
					{
						return false;
					}
					for (long i=0; i<(long)arraySize; i++)
					{
						BSTR arrElement;
						arrElement = ::A2WBSTR((LPCSTR)GetParamValue(paramIndex, i));
						hr = SafeArrayPutElement(outArray, &i, arrElement);
						if (hr != S_OK)
						{
							return false;
						}
					}
					(*outVariant).vt = (VT_ARRAY | VT_BSTR);
					(*outVariant).parray = outArray;
					paramIndex++;
				}
			}
			break;
		}
		//cur = parent->next;
		//parent = cur;
	}
	ExitLog;
	return true;
}
bool SecureXmlPayload::CreatePayloadXml()
{
	char buffer[64];
	xmlNodePtr cur=NULL, parent1=NULL, parent=NULL, rootNode=NULL;

	EnterLog;
	memset(buffer, 0, 64);

	if (doc != NULL)
		xmlFreeDoc(doc);
	doc = NULL;
	if (charXmlDocPtr != NULL)
		xmlFree(charXmlDocPtr);
	charXmlDocSize = 0;
	charXmlDocPtr = NULL;

	doc = xmlNewDoc((const unsigned char *)"1.0");

	// document, namespace, element name, element content
	cur = xmlNewDocNode(doc,NULL,(const unsigned char *)"SecureXML_Payload",NULL);

	// add root element
	xmlDocSetRootElement(doc,cur);
	rootNode = cur;

	cur = xmlNewNode(NULL,(const unsigned char *)"SourceProcess_Id"); 
	sprintf(buffer, (const char *)"%d", SourceProcessId);
	xmlNodeSetContent(cur,(const unsigned char *)buffer);
	cur = xmlAddChild(rootNode,cur);

	cur = xmlNewNode(NULL,(const unsigned char *)"Nonce"); 
	xmlNodeSetContent(cur,(const unsigned char *)Nonce);
	cur = xmlAddChild(rootNode,cur);

	cur = xmlNewNode(NULL,(const unsigned char *)"SignatureObject_Id"); 
	sprintf(buffer, (const char *)"%d", SignatureObjectId);
	xmlNodeSetContent(cur,(const unsigned char *)buffer);
	cur = xmlAddChild(rootNode,cur);

	cur = xmlNewNode(NULL,(const unsigned char *)"API"); 
	cur = xmlAddChild(rootNode,cur);
	parent = cur;

	cur = xmlNewNode(NULL,(const unsigned char *)"API_Name");
	xmlNodeSetContent(cur,(const unsigned char *)ApiName);
	cur = xmlAddChild(parent,cur);

	cur = xmlNewNode(NULL,(const unsigned char *)"Param_Count");
	sprintf(buffer, (const char *)"%d", ParamCount);
	xmlNodeSetContent(cur,(const unsigned char *)buffer);
	cur = xmlAddChild(parent,cur);

	for (int i=0; i < ParamCount; i++)
	{
		cur = xmlNewNode(NULL,(const unsigned char *)"Param");
		xmlNewProp(cur, (const unsigned char *)"Type", (const unsigned char *)ParamTypeArray[i].paramType);
		if ((ParamIsArrayArray[i] == true) && (ParamArraySizeArray[i] > 0))
		{
			sprintf(buffer, (const char *)"%d", ParamArraySizeArray[i]);
			xmlNewProp(cur, (const unsigned char *)"ArraySize", (const unsigned char *)buffer);
		}
		parent1 = cur;
		cur = xmlAddChild(parent, cur);
		for (int j=0; j < ParamArraySizeArray[i]; j++)
		{
			cur = xmlNewNode(NULL, (const unsigned char *)"Value");
			xmlNodeSetContent(cur,(const unsigned char *)ValueArray[i][j]);
			xmlAddChild(parent1,cur);
		}
	}
	ExitLog;
	return true;
}

int SecureXmlPayload::SetParamValue(int paramIndex, int valueIndex, int paramValue)
{
	ExitLog;
	if (paramIndex < ParamCount)
	{
		if (valueIndex < ParamArraySizeArray[paramIndex])
		{
			ValueArray[paramIndex][valueIndex] = (char *)zMalloc(32);
			memset(ValueArray[paramIndex][valueIndex], 0, 32);
			sprintf(ValueArray[paramIndex][valueIndex],"%d", paramValue);
			if (valueIndex == (ParamArraySizeArray[paramIndex] - 1))
			{
				VARIANT *outVariant;
				SAFEARRAY *outArray;
				SAFEARRAYBOUND rgsabound[1];
				HRESULT hr;
				
				outVariant = (VARIANT *)&VariantParamValue[paramIndex];

				VariantInit(outVariant);
				rgsabound[0].lLbound = 0;
				rgsabound[0].cElements = ParamArraySizeArray[paramIndex];

				outArray = SafeArrayCreate(VT_BSTR, 
											1,
											rgsabound);
				if (outArray == NULL)
				{
					return false;
				}
				for (long i=0; i<(long)ParamArraySizeArray[paramIndex]; i++)
				{
					BSTR arrElement;
					arrElement = A2WBSTR((LPCSTR)GetParamValue(paramIndex, i));
					hr = SafeArrayPutElement(outArray, &i, arrElement);
					if (hr != S_OK)
					{
						return false;
					}
				}
				(*outVariant).vt = (VT_ARRAY | VT_BSTR);
				(*outVariant).parray = outArray;
			}
		}
	}
	ExitLog;
	return 0;
}

int SecureXmlPayload::GetParamIntegerValue(int paramIndex, int valueIndex)
{
	return (atoi((const char *)GetParamValue(paramIndex, valueIndex)));
}

int SecureXmlPayload::SetParamValue(int paramIndex, int valueIndex, BSTR paramValue)
{
	unsigned char *charParamValue = NULL;
	charParamValue = HeapW2A(paramValue);
	SetParamValue(paramIndex, valueIndex, (char *)charParamValue);
	zFree(charParamValue);
	return 0;
}
