// TestSecureXmlPayload.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Signature.h"
#include "SecureXmlPayload.h"

#ifndef WIN32
#include <securexml/CharConversion.h>
#endif

OLECHAR szModulePath[MAX_PATH];
CComModule _Module;

SecureXmlPayload *InvokeAPI(SecureXmlPayload *iPayload)
{
	SecureXmlPayload *oPayload = new SecureXmlPayload();
	CSignature *sigObj=NULL;

	char *apiName = iPayload->GetApiName();
	oPayload->SetApiName((const char *)apiName);
	oPayload->SetNonce((const char *)iPayload->GetNonce());
	oPayload->SetSourceProcessId(GetCurrentProcessId());

	sigObj = (CSignature *)iPayload->GetSignatureObjectId();
	if (!(strcmp((const char *)apiName, (const char *)"createSignatureObject")))
	{
		sigObj = new CSignature();
		oPayload->SetParamCount(1);
		oPayload->SetParamType(0, "Integer" , false, 1);
		oPayload->SetParamValue(0,0,(int) sigObj);
		oPayload->SetSignatureObjectId((unsigned long)sigObj);
		return oPayload;
	}
	if (sigObj == NULL)
	{
		return NULL;
	}
	else
	{
		oPayload->SetSignatureObjectId((unsigned long)sigObj);
		if (!(strcmp((const char *)apiName, (const char *)"destroySignatureObject")))
		{
			delete sigObj;
			sigObj = NULL;
			oPayload->SetParamCount(0);
			oPayload->SetSignatureObjectId(0);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getEnvelopingFlag")))
		{
			short pVal=0;
			sigObj->get_EnvelopingFlag(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "ShortInteger", false, 1);
			oPayload->SetParamValue(0,0, (int)pVal);
			return oPayload;
		}

		if (!(strcmp((const char *)apiName, (const char *)"setEnvelopingFlag")))
		{
			short pVal=0;
			sigObj->put_EnvelopingFlag((short)iPayload->GetParamIntegerValue(0,0));
			oPayload->SetParamCount(0);
			return oPayload;
		}
		
		if (!(strcmp((const char *)apiName, (const char *)"getHostName")))
		{
			BSTR pVal=NULL;
			sigObj->get_HostName(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getRecipientCertificateStore")))
		{
			BSTR pVal=NULL;
			sigObj->get_RecipientCertificateStore(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setRecipientCertificateStore")))
		{
			BSTR newVal=NULL;
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			sigObj->put_RecipientCertificateStore(newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getSignerCertificate")))
		{
			BSTR pVal=NULL;
			long sigIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			sigObj->get_SignerCertificate(sigIndex, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setSignerCertificate")))
		{
			BSTR newVal=NULL;
			long sigIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(1,0));
			sigObj->put_SignerCertificate(sigIndex, newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getSignatureID")))
		{
			BSTR pVal=NULL;
			long sigIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			sigObj->get_SignatureID(sigIndex, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setSignatureID")))
		{
			BSTR newVal=NULL;
			long sigIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(1,0));
			sigObj->put_SignatureID(sigIndex, newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getProperties")))
		{
			BSTR pVal=NULL;
			long sigIndex=0, propIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			propIndex = iPayload->GetParamIntegerValue(1,0);
			sigObj->get_Properties(sigIndex, propIndex, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setProperties")))
		{
			BSTR newVal=NULL;
			long sigIndex=0, propIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			propIndex = iPayload->GetParamIntegerValue(1,0);
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(2,0));
			sigObj->put_Properties(sigIndex, propIndex, newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getBase64EncodeXML")))
		{
			BOOL pVal=0;
			sigObj->get_Base64EncodeXML(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "Integer", false, 1);
			oPayload->SetParamValue(0,0, (int)pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setBase64EncodeXML")))
		{
			sigObj->put_Base64EncodeXML((BOOL)iPayload->GetParamIntegerValue(0,0));
			oPayload->SetParamCount(0);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getBase64DecodeXML")))
		{
			BOOL pVal=0;
			sigObj->get_Base64DecodeXML(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "Integer", false, 1);
			oPayload->SetParamValue(0,0, (int)pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setBase64DecodeXML")))
		{
			sigObj->put_Base64DecodeXML((BOOL)iPayload->GetParamIntegerValue(0,0));
			oPayload->SetParamCount(0);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getDocumentURI")))
		{
			BSTR pVal=NULL;
			long sigIndex=0, uriIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			uriIndex = iPayload->GetParamIntegerValue(1,0);
			sigObj->get_DocumentURI(sigIndex, uriIndex, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getDigestObjectStatus")))
		{
			BOOL pVal=FALSE;
			long sigIndex=0, uriIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			uriIndex = iPayload->GetParamIntegerValue(1,0);
			sigObj->get_DigestObjectStatus(sigIndex, uriIndex, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "Integer", false, 1);
			oPayload->SetParamValue(0,0,(int)pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getLanguage")))
		{
			BSTR pVal=NULL;
			sigObj->get_Language(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setLanguage")))
		{
			BSTR newVal=NULL;
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			sigObj->put_Language(newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getSignatureStatus")))
		{
			BOOL pVal=FALSE;
			long sigIndex=0;
			sigIndex = iPayload->GetParamIntegerValue(0,0);
			sigObj->get_SignatureStatus(sigIndex, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "Integer", false, 1);
			oPayload->SetParamValue(0,0,(int)pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getPhysicalSignatureUsage")))
		{
			long pVal=0;
			sigObj->get_PhysicalSignatureUsage(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "Integer", false, 1);
			oPayload->SetParamValue(0,0, (int)pVal);
			return oPayload;
		}

		if (!(strcmp((const char *)apiName, (const char *)"setPhysicalSignatureUsage")))
		{
			sigObj->put_PhysicalSignatureUsage((long)iPayload->GetParamIntegerValue(0,0));
			oPayload->SetParamCount(0);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setActiveCertificate")))
		{
			BSTR newVal=NULL;
			BOOL pVal=FALSE;
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			sigObj->SetActiveCertificate(newVal, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "Integer", false, 1);
			oPayload->SetParamValue(0,0, (int)pVal);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getNetscapeStorePassword")))
		{
			BSTR pVal=NULL;
			sigObj->get_NetscapeStorePassword(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setNetscapeStorePassword")))
		{
			BSTR newVal=NULL;
			BOOL pVal=FALSE;
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			sigObj->put_NetscapeStorePassword(newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"getStoreName")))
		{
			BSTR pVal=NULL;
			sigObj->GetStoreName(&pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"setStoreName")))
		{
			BSTR newVal=NULL;
			BOOL pVal=FALSE;
			newVal = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			sigObj->SetStoreName(newVal);
			oPayload->SetParamCount(0);
			SysFreeString(newVal);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"signXMLStr")))
		{
			BSTR newVal1=NULL, newVal2=NULL;
			BSTR pVal=NULL;
			newVal1 = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			newVal2 = A2WBSTR((LPCSTR)iPayload->GetParamValue(1,0));
			sigObj->SignXMLStr(newVal1, newVal2, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			SysFreeString(newVal1);
			SysFreeString(newVal2);
			return oPayload;
		}
		if (!(strcmp((const char *)apiName, (const char *)"signDataStr")))
		{
			BSTR newVal1=NULL;
			BSTR pVal=NULL;
			newVal1 = A2WBSTR((LPCSTR)iPayload->GetParamValue(0,0));
			sigObj->SignDataStr(newVal1, &pVal);
			oPayload->SetParamCount(1);
			oPayload->SetParamType(0, "String", false, 1);
			oPayload->SetParamValue(0,0,pVal);
			SysFreeString(pVal);
			SysFreeString(newVal1);
			return oPayload;
		}
	}
#if 0
/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignDataStr
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsignDataStr
  (JNIEnv *, jobject, jint, jstring);


/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CreadAll
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CreadAll
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsaveXMLStr
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsaveXMLStr
  (JNIEnv *, jobject, jint, jstring, jstring);



	
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetPhysicalSignatureFile
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetPhysicalSignatureFile
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetPhysicalSignatureFile
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCapturedSignatureFile
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCapturedSignatureFile
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Csign
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Csign
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetIncludeCamResponse
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetIncludeCamResponse
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetIncludeCamResponse
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetIncludeCamResponse
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsaveXMLSignature
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsaveXMLSignature
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cverify
 * Signature: (ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_Cverify
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetError
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetError
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetOverwriteFile
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetOverwriteFile
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CpFXExportCertificate
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CpFXExportCertificate
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CverifyDetached
 * Signature: (ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CverifyDetached
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetLastError
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetLastError
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetX509Certificate
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetX509Certificate
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CviewCertificate
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CviewCertificate
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertificateCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertificateCount
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertificateInfo
 * Signature: (III)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertificateInfo
  (JNIEnv *, jobject, jint, jint, jint);


/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedDocumentPath
 * Signature: (III)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedDocumentPath
  (JNIEnv *, jobject, jint, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignerSubject
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignerSubject
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertIssuer
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertIssuer
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertExpiry
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertExpiry
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertSerialNumber
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertSerialNumber
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CfileExists
 * Signature: (ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CfileExists
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetFailedUriCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetFailedUriCount
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetTotalUriCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetTotalUriCount
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetFailedUriFullPath
 * Signature: (II)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetFailedUriFullPath
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetFailedUriFullPath
 * Signature: (IILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetFailedUriFullPath
  (JNIEnv *, jobject, jint, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetFailedUri
 * Signature: (II)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetFailedUri
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignatureCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignatureCount
  (JNIEnv *, jobject, jint);


/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignHTML
 * Signature: (ILjava/lang/Object;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsignHTML
  (JNIEnv *, jobject, jint, jobject);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsecureXMLVerify
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsecureXMLVerify
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCSP
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCSP
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedHTML
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedHTML
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsignFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedFileObject
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedFileObject
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignXMLEnveloped
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsignXMLEnveloped
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetVersion
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetVersion
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetLicenseStatus
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetLicenseStatus
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetPropertyCount
 * Signature: (II)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetPropertyCount
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CviewAnyCertificate
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CviewAnyCertificate
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CselectActiveCertificate
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CselectActiveCertificate
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CverifyXMLStr
 * Signature: (ILjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CverifyXMLStr
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetActivePFXFileCert
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsetActivePFXFileCert
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CpFXExportActiveCertificate
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CpFXExportActiveCertificate
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetHostName
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetHostName
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetTimeStampURL
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetTimeStampURL
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetTimeStampURL
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetTimeStampURL
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetTimeStamping
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetTimeStamping
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetTimeStamping
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetTimeStamping
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetTimeStampFormat
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetTimeStampFormat
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetTimeStampFormat
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetTimeStampFormat
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetTimeStampCritical
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetTimeStampCritical
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetTimeStampCritical
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetTimeStampCritical
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetHostOsType
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetHostOsType
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCrlChecking
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCrlChecking
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCrlChecking
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCrlChecking
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSigCertStatus
 * Signature: (IILjava/lang/String;I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSigCertStatus
  (JNIEnv *, jobject, jint, jint, jstring, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CverifyX509CertCRL
 * Signature: (ILjava/lang/String;Ljava/lang/String;I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CverifyX509CertCRL
  (JNIEnv *, jobject, jint, jstring, jstring, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CverifyPFXCertCRL
 * Signature: (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CverifyPFXCertCRL
  (JNIEnv *, jobject, jint, jstring, jstring, jstring, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetAddWindowImage
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetAddWindowImage
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetAddWindowImage
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetAddWindowImage
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCRLLocation
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCRLLocation
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CverifyActiveCertificate
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CverifyActiveCertificate
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertificatePolicy
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertificatePolicy
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetAuthorityConstrainedPolicy
 * Signature: (I)[Ljava/lang/String;
 */
JNIEXPORT jobjectArray JNICALL Java_infomosaic_securexml_SignatureImpl_CgetAuthorityConstrainedPolicy
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetUserConstrainedPolicy
 * Signature: (I)[Ljava/lang/String;
 */
JNIEXPORT jobjectArray JNICALL Java_infomosaic_securexml_SignatureImpl_CgetUserConstrainedPolicy
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertificatePolicyChecking
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertificatePolicyChecking
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertificateChainValidation
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertificateChainValidation
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertificatePathLengthChecking
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertificatePathLengthChecking
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetConfigFileName
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetConfigFileName
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetDoDCompliance
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetDoDCompliance
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertificatePolicyExplicit
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertificatePolicyExplicit
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertificatePolicyExplicit
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertificatePolicyExplicit
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertificateTrustExplicit
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertificateTrustExplicit
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignXMLXpathStr
 * Signature: (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsignXMLXpathStr
  (JNIEnv *, jobject, jint, jstring, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetUseHMAC
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetUseHMAC
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetUseHMAC
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetUseHMAC
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetHMACPassword
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetHMACPassword
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetHMACPassword
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetHMACPassword
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CchangeOrAddProperty
 * Signature: (ILjava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CchangeOrAddProperty
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetDetailedVerificationFlag
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetDetailedVerificationFlag
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CcaptureLiveSignature
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CcaptureLiveSignature
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetExcludeSignerCertificate
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetExcludeSignerCertificate
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CcoSignXMLStr
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CcoSignXMLStr
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CcoSignFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CcoSignFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignFiles
 * Signature: (I[Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsignFiles
  (JNIEnv *, jobject, jint, jobjectArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetRecipientCertificates
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetRecipientCertificates
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CencryptStr
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CencryptStr
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CdecryptStr
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CdecryptStr
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CencryptFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CencryptFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CdecryptFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CdecryptFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetTrustedRoots
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetTrustedRoots
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetRecipientCertificateFiles
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetRecipientCertificateFiles
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetDetachedObjects
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetDetachedObjects
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetAttachedObjects
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetAttachedObjects
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CreadAllBase64
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CreadAllBase64
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetDecryptionPFXCertFile
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetDecryptionPFXCertFile
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetDecryptUsingPFXFileCert
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetDecryptUsingPFXFileCert
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetDecryptionPFXPassword
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetDecryptionPFXPassword
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetXpathNamespace
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetXpathNamespace
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCamServerHost
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCamServerHost
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCamServerHost
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCamServerHost
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCamServerPort
 * Signature: (I)S
 */
JNIEXPORT jshort JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCamServerPort
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCamServerPort
 * Signature: (IS)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCamServerPort
  (JNIEnv *, jobject, jint, jshort);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetUseCam
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetUseCam
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetUseCam
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetUseCam
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetAgencyId
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetAgencyId
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetAgencyId
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetAgencyId
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCamValidationResponse
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCamValidationResponse
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSigPropValueByName
 * Signature: (IILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSigPropValueByName
  (JNIEnv *, jobject, jint, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64DecodeBufferToFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64DecodeBufferToFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64DecodeFileToFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64DecodeFileToFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgunZipFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgunZipFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertSerialNumberFormat
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertSerialNumberFormat
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertSerialNumberFormat
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertSerialNumberFormat
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsecureXMLVerifyFileToBuffer
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsecureXMLVerifyFileToBuffer
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsecureXMLVerifyFileToFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsecureXMLVerifyFileToFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CdeleteSignatureFromXMLStr
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CdeleteSignatureFromXMLStr
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CdeleteSignatureFromFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CdeleteSignatureFromFile
  (JNIEnv *, jobject, jint, jstring, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetAllowedCertIssuerNames
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetAllowedCertIssuerNames
  (JNIEnv *, jobject, jint, jobjectArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCRLCacheDbConnectionString
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCRLCacheDbConnectionString
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCRLCacheDbConnectionString
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCRLCacheDbConnectionString
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetUseCRLCache
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetUseCRLCache
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetUseCRLCache
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetUseCRLCache
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCRLCacheTimeoutInMinutes
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCRLCacheTimeoutInMinutes
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCanonicalizationMethod
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCanonicalizationMethod
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetActivePEMFileCert
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsetActivePEMFileCert
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSecureXMLPath
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSecureXMLPath
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedDocumentCount
 * Signature: (II)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedDocumentCount
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignXMLByteArray
 * Signature: (I[BLjava/lang/String;)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CsignXMLByteArray
  (JNIEnv *, jobject, jint, jbyteArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsaveXMLByteArray
 * Signature: (I[BLjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsaveXMLByteArray
  (JNIEnv *, jobject, jint, jbyteArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CreadAllByteArray
 * Signature: (ILjava/lang/String;)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CreadAllByteArray
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CverifyXMLByteArray
 * Signature: (I[B)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CverifyXMLByteArray
  (JNIEnv *, jobject, jint, jbyteArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsecureXMLVerifyByteArray
 * Signature: (I[B)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CsecureXMLVerifyByteArray
  (JNIEnv *, jobject, jint, jbyteArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignXMLXpathByteArray
 * Signature: (I[BLjava/lang/String;Ljava/lang/String;)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CsignXMLXpathByteArray
  (JNIEnv *, jobject, jint, jbyteArray, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignXMLEnvelopedByteArray
 * Signature: (I[BLjava/lang/String;)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CsignXMLEnvelopedByteArray
  (JNIEnv *, jobject, jint, jbyteArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64DecodeByteArrayToFile
 * Signature: (I[BLjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64DecodeByteArrayToFile
  (JNIEnv *, jobject, jint, jbyteArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64DecodeByteArrayToByteArray
 * Signature: (I[B)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64DecodeByteArrayToByteArray
  (JNIEnv *, jobject, jint, jbyteArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64EncodeByteArrayToByteArray
 * Signature: (I[B)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64EncodeByteArrayToByteArray
  (JNIEnv *, jobject, jint, jbyteArray);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64EncodeByteArrayToFile
 * Signature: (I[BLjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64EncodeByteArrayToFile
  (JNIEnv *, jobject, jint, jbyteArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64EncodeStrToFile
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64EncodeStrToFile
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    Cbase64EncodeStrToStr
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_Cbase64EncodeStrToStr
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetActivePFXB64Data
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsetActivePFXB64Data
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetFloatingLicense
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetFloatingLicense
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetFloatingLicense
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetFloatingLicense
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetLicensedUserCount
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetLicensedUserCount
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetIncludeCRLInSignature
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetIncludeCRLInSignature
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetUsedCRLList
 * Signature: (I)[Ljava/lang/String;
 */
JNIEXPORT jobjectArray JNICALL Java_infomosaic_securexml_SignatureImpl_CgetUsedCRLList
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetErrorDetail
 * Signature: (II)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetErrorDetail
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetPhysicalSignatureB64Str
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetPhysicalSignatureB64Str
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedInfoDigest
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedInfoDigest
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetX509CertificateChain
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetX509CertificateChain
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetSignerCertificateChain
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetSignerCertificateChain
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetSignatureImageId
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetSignatureImageId
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignatureImageId
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignatureImageId
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsignSignedInfoDigest
 * Signature: (ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CsignSignedInfoDigest
  (JNIEnv *, jobject, jint, jstring, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CapplySignatureValue
 * Signature: (ILjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CapplySignatureValue
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedInfoDigestFromByteArray
 * Signature: (I[BLjava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedInfoDigestFromByteArray
  (JNIEnv *, jobject, jint, jbyteArray, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CapplySignatureValueGetByteArray
 * Signature: (ILjava/lang/String;)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CapplySignatureValueGetByteArray
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedDocumentB64Str
 * Signature: (III)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedDocumentB64Str
  (JNIEnv *, jobject, jint, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignedDocumentByteArray
 * Signature: (III)[B
 */
JNIEXPORT jbyteArray JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignedDocumentByteArray
  (JNIEnv *, jobject, jint, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertValidationTransactionId
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertValidationTransactionId
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetCertValidationTransactionId
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetCertValidationTransactionId
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetIgnoreIncompleteSignature
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetIgnoreIncompleteSignature
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetIgnoreIncompleteSignature
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetIgnoreIncompleteSignature
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetSignatureIndexToVerify
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetSignatureIndexToVerify
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetSignatureIndexToVerify
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetSignatureIndexToVerify
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetUseOcsp
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetUseOcsp
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetUseOcsp
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetUseOcsp
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetOcspTrustedRespSignerCertPath
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetOcspTrustedRespSignerCertPath
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetOcspTrustedRespSignerCertPath
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetOcspTrustedRespSignerCertPath
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetOcspReqSignerPFXCertPath
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetOcspReqSignerPFXCertPath
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetOcspReqSignerPFXCertPath
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetOcspReqSignerPFXCertPath
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetOcspReqSignerPFXCertPassword
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetOcspReqSignerPFXCertPassword
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetOcspReqSignerPFXCertPassword
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetOcspReqSignerPFXCertPassword
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetOcspResponderURL
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetOcspResponderURL
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetOcspResponderURL
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetOcspResponderURL
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetOcspTextResponse
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetOcspTextResponse
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetOcspB64Response
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetOcspB64Response
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetCertRevocationDate
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_infomosaic_securexml_SignatureImpl_CgetCertRevocationDate
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CgetIncludeOcspResponse
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_infomosaic_securexml_SignatureImpl_CgetIncludeOcspResponse
  (JNIEnv *, jobject, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetIncludeOcspResponse
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetIncludeOcspResponse
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetProxyHost
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetProxyHost
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetProxyPort
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetProxyPort
  (JNIEnv *, jobject, jint, jint);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetProxyUserName
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetProxyUserName
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetProxyPassword
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetProxyPassword
  (JNIEnv *, jobject, jint, jstring);

/*
 * Class:     infomosaic_securexml_SignatureImpl
 * Method:    CsetInclusiveNamespacePrefixList
 * Signature: (I[Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_infomosaic_securexml_SignatureImpl_CsetInclusiveNamespacePrefixList
  (JNIEnv *, jobject, jint, jobjectArray);
#endif
	return oPayload;
}

int _tmain(int argc, _TCHAR* argv[])
{
	unsigned long xmlByteSize;
	FILE *fp;
	bool isArray=false;
	int  arraySize=0;
	
	EnterLog;

	SecureXmlPayload *sp = new SecureXmlPayload();
	sp->SetSourceProcessId(1);
	sp->SetSignatureObjectId(9);
	sp->SetApiName((const char *)"setCRLLocation");
	sp->SetNonce((const char *)"This is my nonce 1");
	sp->SetParamCount(3);
	
	sp->SetParamType(0, "StringArray", true, 3);
	sp->SetParamValue(0, 0, "http://www.infomosaic.com");
	sp->SetParamValue(0, 1, "http://www.infomosaic.net");
	sp->SetParamValue(0, 2, "http://www.infomosaic.org");

	sp->SetParamType(1, "String", false, 1);
	sp->SetParamValue(1, 0, "This is param 2");

	sp->SetParamType(2, "StringArray", true, 3);
	sp->SetParamValue(2, 0, "This is param 3 item 0");
	sp->SetParamValue(2, 1, "This is param 3 item 1");
	sp->SetParamValue(2, 2, "This is param 3 item 2");

	char *payloadXml = sp->GetPayloadXml(&xmlByteSize);
	fp = fopen((const char *)"output1.xml", (const char *)"w");
	fprintf(fp,"%s\n", payloadXml);
	fclose(fp);

	char *payloadXmlSaved = (char *)malloc(xmlByteSize + 1);
	memset(payloadXmlSaved, 0, xmlByteSize + 1);
	memcpy(payloadXmlSaved, payloadXml, xmlByteSize);

	sp->SetSourceProcessId(2);
	sp->SetSignatureObjectId(8);
	sp->SetApiName((const char *)"getCRLLocation");
	sp->SetNonce((const char *)"This is my nonce 2");
	sp->SetParamCount(1);
	sp->SetParamType(0, "StringArray", true, 3);
	sp->SetParamValue(0, 0, "http://www.infomosaic.org");
	sp->SetParamValue(0, 1, "http://www.infomosaic.com");
	sp->SetParamValue(0, 2, "http://www.infomosaic.net");
	payloadXml = sp->GetPayloadXml(&xmlByteSize);
	fp = fopen((const char *)"output2.xml", (const char *)"w");
	fprintf(fp,"%s\n", payloadXml);
	fclose(fp);

	sp->SetSourceProcessId(3);
	sp->SetSignatureObjectId(7);
	sp->SetApiName((const char *)"getSecureXMLPath");
	sp->SetNonce((const char *)"This is my nonce 3");
	sp->SetParamCount(1);
	sp->SetParamType(0, "String", false, 0);
	sp->SetParamValue(0, 0, "C:\\temp");
	payloadXml = sp->GetPayloadXml(&xmlByteSize);
	fp = fopen((const char *)"output3.xml", (const char *)"w");
	fprintf(fp,"%s\n", payloadXml);
	fclose(fp);

	delete sp;

	sp = new SecureXmlPayload();

	sp->SetPayloadXml((const char *)payloadXmlSaved);
	printf("Source Process Id = %d\n", sp->GetSourceProcessId());
	printf("Signature Object Id = %d\n", sp->GetSignatureObjectId());
	printf("Api Name = %s\n", sp->GetApiName());
	printf("Nonce = %s\n", sp->GetNonce());
	printf("Param Count = %d\n", sp->GetParamCount());
	for (int i=0; i < sp->GetParamCount(); i++)
	{
		char * dataType = sp->GetParamType(i, &isArray, &arraySize);
		printf("Param %d Param Type = %s, isArray = %d, ArraySize = %d\n", i, dataType, isArray, arraySize);
	}
	payloadXml = sp->GetPayloadXml(&xmlByteSize);
	fp = fopen((const char *)"output4.xml", (const char *)"w");
	fprintf(fp,"%s\n", payloadXml);
	fclose(fp);
	free(payloadXmlSaved);

	VARIANT paramValue = sp->GetParamValue(0);
	unsigned int itemCount;
	BSTR *bstrList = GetBstrArrayFromVariant(paramValue, &itemCount);
	printf("Item Count = %d\n", itemCount);
	for (unsigned int itemIndex=0; itemIndex < itemCount; itemIndex++)
	{
		char *charItemValue = (char *)HeapW2A(bstrList[itemIndex]);
		printf("Item Value = %s\n", charItemValue);
		SysFreeString(bstrList[itemIndex]);
		zFree(charItemValue);
	}
	zFree(bstrList);

	sp->SetApiName("createSignatureObject");
	sp->SetSignatureObjectId((unsigned long)0);
	sp->SetParamCount(0);
	SecureXmlPayload *oPayload = InvokeAPI(sp);
	if (oPayload != NULL)
	{
		sp->SetApiName("getHostName");
		sp->SetSignatureObjectId(oPayload->GetSignatureObjectId());
		delete oPayload;
		sp->SetParamCount(0);
		oPayload = InvokeAPI(sp);
		payloadXml = oPayload->GetPayloadXml(&xmlByteSize);
		printf("SecureXMLPath XML = %s\n", payloadXml);
		delete oPayload;
		sp->SetApiName("signDataStr");
		sp->SetParamCount(1);
		sp->SetParamType(0, "String", false, 1);
		sp->SetParamValue(0,0, (char *)"This is a test");
		oPayload = InvokeAPI(sp);
		payloadXml = oPayload->GetPayloadXml(&xmlByteSize);
		printf("Signed Xml = %s\n", payloadXml);
		delete oPayload;
		sp->SetApiName("destroySignatureObject");
		oPayload = InvokeAPI(sp);
		delete oPayload;
	}
	delete sp;
#ifdef LOGGING
	DumpUnfreed();
#endif
	ExitLog;
	return 0;
}

